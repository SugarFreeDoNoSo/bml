#!/usr/bin/env python3
"""Prepare and execute one CURRENT graph21 workspace replay, never historical9a."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import fcntl
import hashlib
import importlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time

BASE = '7f1429255db537f9ae1440f9ec2f234d03e7419c'
PATCH_SHA = '57f536ce71dac6b4662080c7ad9c19646634a496852e72b7baee6391b0a7cc33'
MARKER = "/* ~ changed by cargo-mutants ~ */"
FILES = {'crates/api/src/main.rs': ('6ab43e13fdf326499ee2f5d8e34103b3f684d33c73164bb54954f118434bce64', '19a8c6b503fbf73c4db91a514d55bea9170c07f020f74fb68cae3ac11cfe7ad9'), 'crates/domain/src/number/exact.rs': ('da29637bbc49161ca1e684f87bd0e1f971af89e9ed9ff8eda3f2d7af024a73bf', 'cbab81b1a6501357683f0e8b15d8b3e375010bf93efbedfe124915370de0c549'), 'crates/runtime/src/graph.rs': ('7af83e2bd5b5e91db69ac05d235a57266350d2611bcb70bf626b1688ad2b3666', '1a586bb31524f24bf517d25fb91b92cd46a2fd99d379f743c04ac128d1b8dfba')}
LIST_FILES = ['crates/runtime/src/graph.rs']
BUILD = ["cargo", "test", "--no-run", "--workspace", "--locked"]
TEST = ["cargo", "test", "--workspace", "--locked"]
SELECTORS = [('graph-skip-boundary', 'crates/runtime/src/graph.rs', 'structure', '<=', 'bml-runtime')]
EXPECTED_BASELINE_PASSED = 1003
EXPECTED_CURRENT_INVENTORY_SHA256 = 'a00c49cc9f01fa522bcf72e2eb54ed31eac261cd7f8dbfecb23f9554f2992251'
EXPECTED_CANDIDATES = {'graph-skip-boundary': {'name': 'crates/runtime/src/graph.rs:419:14: replace < with <= in structure', 'span': {'start': {'line': 419, 'column': 14}, 'end': {'line': 419, 'column': 15}}, 'original': '<'}}
EXPECTED_PREVIOUS_SOURCE_SHA256 = '4733ba811f59d2e50874781087bcd9a86c665e7ca95049303b8b217fbd4471e7'
EXPECTED_PREVIOUS_REPORT_SHA256 = 'c1c090cf9fdf85d08aca7faf22f6f905153196d35cb707365a3f3de7f796133c'


def require(value, reason):
    if not value:
        raise RuntimeError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def now():
    return datetime.now(timezone.utc).isoformat()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def json_new(path, value):
    write_new(path, (json.dumps(value, indent=2, allow_nan=False) + "\n").encode())


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root)


def inventory(root):
    paths = git(root, "ls-files", "-z").decode().split("\0")
    return {name: sha(os.readlink(root / name).encode() if (root / name).is_symlink()
                      else (root / name).read_bytes()) for name in paths if name}


def env_for(target, temporary):
    env = os.environ.copy()
    for key in list(env):
        if key.startswith("CARGO_MUTANTS_") or key in {
            "CARGO", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS",
            "RUSTUP_TOOLCHAIN", "CARGO_BUILD_TARGET",
        }:
            env.pop(key)
    env.update(CARGO_TARGET_DIR=str(target), CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="1", TMPDIR=str(temporary),
               CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
               PROPTEST_RNG_SEED="20260923", CARGO_TERM_COLOR="never")
    return env


def span_offsets(text, span):
    # 27.1.0 LineColumn counts Unicode chars, not UTF-8 bytes (span.rs).
    require("\r" not in text, "this frozen source contract requires LF files")
    lines = text.splitlines(keepends=True)
    offsets = []
    for side in ("start", "end"):
        position = span[side]
        line, column = position["line"], position["column"]
        require(1 <= line <= len(lines) and 1 <= column <= len(lines[line - 1]) + 1, "invalid producer span")
        offsets.append(sum(len(value) for value in lines[:line - 1]) + column - 1)
    require(0 <= offsets[0] < offsets[1] <= len(text), "empty or invalid producer span")
    return offsets


def apply_diff(text, diff):
    """Strictly replay producer hunks and compare them with the span replacement."""
    original = text.splitlines(keepends=True)
    patch = diff.splitlines(keepends=True)
    require(len(patch) >= 3 and patch[0].startswith("--- ") and patch[1].startswith("+++ "), "invalid producer diff header")
    result, cursor, position = [], 0, 2
    while position < len(patch):
        match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?", patch[position])
        require(match is not None, "invalid producer hunk")
        start = int(match[1]) - 1
        old_count, new_count = int(match[2] or 1), int(match[4] or 1)
        require(cursor <= start <= len(original), "overlapping producer hunks")
        result.extend(original[cursor:start]); cursor = start; position += 1
        old_seen = new_seen = 0
        while position < len(patch) and not patch[position].startswith("@@ "):
            line = patch[position]; position += 1
            require(line[:1] in {" ", "+", "-"}, "unsupported producer diff line")
            if line[0] != "+":
                require(cursor < len(original) and original[cursor] == line[1:], "producer diff context differs")
                cursor += 1; old_seen += 1
            if line[0] != "-":
                result.append(line[1:]); new_seen += 1
        require((old_seen, new_seen) == (old_count, new_count), "producer hunk counts differ")
    result.extend(original[cursor:])
    return "".join(result)


class Runner:
    def __init__(self, output, worktree, target, build_timeout, test_timeout):
        self.output, self.worktree, self.target = output, worktree, target
        self.build_timeout, self.test_timeout = build_timeout, test_timeout
        temporary = output / "tmp"; temporary.mkdir(exist_ok=True)
        self.env = env_for(target, temporary)
        self.report = {"scope": "One CURRENT graph21 source replay with exact whole-workspace commands; not historical9a or a complete mutation campaign.",
                       "runner_pid": os.getpid(), "started_at": now(), "commands": [], "cases": [], "active": None}

    def persist(self):
        self.report["updated_at"] = now()
        temporary = self.output / "report.tmp"
        temporary.write_text(json.dumps(self.report, indent=2, allow_nan=False) + "\n")
        temporary.replace(self.output / "report.json")

    def command(self, label, argv, timeout):
        stdout, stderr = self.output / (label + ".stdout"), self.output / (label + ".stderr")
        started = time.monotonic()
        row = {"label": label, "argv": argv, "timeout_seconds": timeout, "started_at": now(),
               "stdout": stdout.name, "stderr": stderr.name,
               "disk_free_before": shutil.disk_usage(self.target).free}
        with stdout.open("xb") as out, stderr.open("xb") as err:
            process = subprocess.Popen(argv, cwd=self.worktree, env=self.env, stdout=out, stderr=err, start_new_session=True)
            self.report["active"] = {"pid": process.pid, "process_group": process.pid, "label": label, "argv": argv}
            self.persist()
            print(f"RUN {label} pid={process.pid}", flush=True)
            try:
                try:
                    row["exit_code"] = process.wait(timeout=timeout)
                    row["timed_out"] = False
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL); process.wait()
                    row.update(exit_code=process.returncode, timed_out=True)
            except BaseException:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL); process.wait()
                raise
            finally:
                self.report["active"] = None
                row.update(ended_at=now(), elapsed_seconds=time.monotonic() - started)
        row.update(stdout_sha256=file_sha(stdout), stderr_sha256=file_sha(stderr),
                   disk_free_after=shutil.disk_usage(self.target).free)
        self.report["commands"].append(row); self.persist()
        return row

    def clean(self, label):
        row = self.command(label, ["cargo", "clean", "--locked", "-p", "bml-runtime", "-p", "bml-domain", "-p", "bml-server"], self.build_timeout)
        require(row["exit_code"] == 0 and not row["timed_out"], "mutated-package cleanup failed")

    def pair(self, label):
        build = self.command(label + "-build", BUILD, self.build_timeout)
        if build["exit_code"] != 0 or build["timed_out"]:
            return {"build": build, "test": None, "caught_current_workspace": False}
        test = self.command(label + "-test", TEST, self.test_timeout)
        text = (self.output / test["stdout"]).read_text(errors="replace") + "\n" + (self.output / test["stderr"]).read_text(errors="replace")
        failed = re.findall(r"^test (\S+) \.\.\. FAILED$", text, re.MULTILINE)
        compile_error = re.search(r"^error(?:\[[^]]+\])?: could not compile\b", text, re.MULTILINE) is not None
        caught = (test["argv"] == TEST and test["exit_code"] == 101 and not test["timed_out"]
                  and "test result: FAILED." in text and bool(failed) and not compile_error)
        return {"build": build, "test": test, "failed_tests": failed, "compile_error": compile_error,
                "caught_current_workspace": caught}


def lock(worktree):
    directory = worktree / "target"; directory.mkdir(exist_ok=True)
    stream = (directory / ".wave12-current.lock").open("a")
    fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
    return stream


def prepare(args):
    root = args.worktree.resolve(); output = args.output.resolve(); target = args.build_target.resolve()
    require((root / ".git").is_file(), "replays require a linked isolated worktree, never main")
    require(args.reuse_from is not None and args.reuse_from.resolve() == Path("/home/dev/Work/bml/target/quality/wave-twenty-current-20261105T115206Z"),
            "this frozen graph21 replay requires the exact completed CURRENT3 parent")
    require(target == Path("/home/dev/Work/bml/target/wave-twelve-current-build-20261105T092132Z"),
            "this frozen graph21 replay requires the reviewed owned target")
    require(git(root, "rev-parse", "HEAD").decode().strip() == BASE, "expected published 7f14292 base, not historical9a")
    require(not output.exists(), "output must be new; preserve all previous receipts")
    cache_receipt = None
    if args.reuse_from is None:
        require(not target.exists(), "exclusive replay target must be new without --reuse-from")
    else:
        previous = args.reuse_from.resolve()
        old_source = json.loads((previous / "source.json").read_text())
        old_report = json.loads((previous / "report.json").read_text())
        require(file_sha(previous / "source.json") == EXPECTED_PREVIOUS_SOURCE_SHA256
                and file_sha(previous / "report.json") == EXPECTED_PREVIOUS_REPORT_SHA256,
                "previous CURRENT3 wave20 receipt hashes differ")
        require(Path(old_source["build_target"]) == target and (target / ".wave12-owned").read_text() == str(previous), "previous target ownership differs")
        require(old_report.get("all_tracked_inputs_restored") is True and len(old_report.get("cases", [])) == 3 and all(case["caught_current_workspace"] for case in old_report["cases"]) and old_report.get("status") == "passed_current_workspace_replays"
                and old_report.get("active") is None, "cache reuse requires the completed restored three-case CURRENT3 wave20 parent")
        require(file_sha(previous / "runner.py") == "81498982bb27ce6bdfce33dfe4a9c5582f5e673ee8547df9899fab716cbe2419"
                and old_source["runner_sha256"] == file_sha(previous / "runner.py"), "previous reviewed CURRENT3 runner differs")
        require(len(old_source["files"]) == 853, "previous CURRENT3 must contain853 tracked inputs")
        require(old_report.get("prepared_source_sha256") == EXPECTED_PREVIOUS_SOURCE_SHA256,
                "previous CURRENT3 report is not bound to frozen source receipt")
        old_tree = Path(old_source["worktree"])
        require(inventory(old_tree) == old_source["files"], "previous replay worktree is no longer restored")
        current = inventory(root)
        changed_inputs = sorted(name for name in set(current) | set(old_source["files"])
                                if current.get(name) != old_source["files"].get(name))
        require(sha((json.dumps(current, sort_keys=True, separators=(",", ":")) + "\n").encode())
                == EXPECTED_CURRENT_INVENTORY_SHA256, "CURRENT base-plus-three-Rust-file inventory differs")
        cache_receipt = {"previous_output": str(previous), "previous_source_sha256": file_sha(previous / "source.json"),
                         "previous_report_sha256": file_sha(previous / "report.json"),
                         "changed_source_paths": changed_inputs,
                         "published_base": BASE, "patch_paths_against_published_base": sorted(FILES),
                         "current_inventory_sha256": EXPECTED_CURRENT_INVENTORY_SHA256,
                         "policy": "Reuse only the owned restored completed three-case CURRENT3 wave20 target for 7f14292 plus the three exact reviewed Rust overlays. Require exact source/report/runner hashes and restored853 inventory before ownership transfer. Clean bml-runtime, bml-domain and bml-server before baseline, the one negative and after restoration. Preserve previous source/worktrees/receipts; no CURRENT outcome before producer listing and workspace baseline plus negative."}
    require(file_sha(args.patch) == PATCH_SHA, "reviewed graph21 combined patch differs")
    expected_patch = git(root, "diff", "--no-ext-diff", "--no-textconv", "--no-color", "--binary", BASE, "--", *FILES)
    require(expected_patch == args.patch.read_bytes(), "current worktree does not contain the exact reviewed patch")
    require(set(git(root, "diff", "--name-only", "HEAD").decode().splitlines()) == set(FILES), "unexpected dirty tracked files")
    require(not git(root, "ls-files", "--others", "--exclude-standard").strip(), "unexpected untracked source inputs")
    for name, (before, after) in FILES.items():
        require(sha(git(root, "show", BASE + ":" + name)) == before, "base hash differs: " + name)
        require(file_sha(root / name) == after, "current hash differs: " + name)
    output.mkdir(parents=True)
    if cache_receipt is None:
        target.mkdir(parents=True); write_new(target / ".wave12-owned", str(output).encode())
    else:
        (target / ".wave12-owned").write_text(str(output))
    runner = Runner(output, root, target, args.build_timeout, args.test_timeout)
    frozen = inventory(root)
    for name in FILES:
        write_new(output / "original" / name, (root / name).read_bytes())
    write_new(output / "reviewed.patch", args.patch.read_bytes())
    write_new(output / "runner.py", Path(__file__).read_bytes())
    version = runner.command("producer-version", ["cargo", "mutants", "--version"], 120)
    require(version["exit_code"] == 0 and not version["timed_out"], "producer version failed")
    require((output / version["stdout"]).read_text().strip() == "cargo-mutants 27.1.0", "producer must be exactly cargo-mutants27.1.0")
    for label, argv in [("cargo-version", ["cargo", "--version"]), ("rustc-version", ["rustc", "--version", "--verbose"])]:
        result = runner.command(label, argv, 120)
        require(result["exit_code"] == 0 and not result["timed_out"], "toolchain version failed")
    require("1.98.1" in (output / "rustc-version.stdout").read_text(), "pinned rustc differs")
    metadata_row = runner.command("workspace-metadata", ["cargo", "metadata", "--locked", "--no-deps", "--format-version", "1"], 120)
    require(metadata_row["exit_code"] == 0 and not metadata_row["timed_out"], "workspace metadata failed")
    metadata = json.loads((output / metadata_row["stdout"]).read_text())
    packages = {package["name"]: package["version"] for package in metadata["packages"] if package["id"] in metadata["workspace_members"]}
    require({"bml", "bml-tests", "bml-domain", "bml-runtime"} <= set(packages), "workspace/facade scope incomplete")
    listing_argv = ["cargo", "mutants", "--no-config", "--workspace", "--test-workspace", "true", "--cargo-arg=--locked", "--list", "--json"]
    for name in LIST_FILES:
        listing_argv += ["--file", name]
    listing_row = runner.command("current-mutants", listing_argv, 120)
    require(listing_row["exit_code"] == 0 and not listing_row["timed_out"], "current producer listing failed")
    candidates = json.loads((output / listing_row["stdout"]).read_text())
    selected = []
    for label, name, function, replacement, package in SELECTORS:
        found = [candidate for candidate in candidates if candidate["file"] == name
                 and (candidate.get("function") or {}).get("function_name") == function and candidate["replacement"] == replacement]
        expected = EXPECTED_CANDIDATES[label]
        found = [candidate for candidate in found if candidate["name"] == expected["name"]
                 and candidate["span"] == expected["span"]]
        require(len(found) == 1, "producer did not generate exactly one current candidate: " + label)
        candidate = found[0]; require(candidate["package"] == package and package in packages, "candidate package mismatch")
        text = (root / name).read_text(); start, end = span_offsets(text, candidate["span"])
        require(text[start:end] == expected["original"], "mutation does not target the exact CURRENT operator")
        changed = text[:start] + replacement + " " + MARKER + text[end:]
        require(apply_diff(text, candidate["diff"]) == changed, "producer span/marker/diff disagree")
        write_new(output / "mutated" / (label + ".rs"), changed.encode())
        selected.append({"label": label, "candidate": candidate, "original_sha256": file_sha(root / name),
                         "mutated_sha256": sha(changed.encode()), "producer_diff_sha256": sha(candidate["diff"].encode())})
    require(inventory(root) == frozen, "source changed while preparing")
    contract = {"identity": "CURRENT published 7f14292 plus exact UTF8, normalize and finite graph structure Rust overlays; not historical9a",
                "worktree": str(root), "git_head": BASE, "patch_sha256": PATCH_SHA,
                "files": frozen, "selected": selected, "workspace_packages": packages,
                "producer_listing_sha256": file_sha(output / listing_row["stdout"]), "producer_argv": listing_argv,
                "producer_binary_sha256": file_sha(Path(shutil.which("cargo-mutants", path=runner.env["PATH"]))),
                "runner_sha256": file_sha(Path(__file__)), "build_target": str(target), "cache_receipt": cache_receipt,
                "build_timeout": args.build_timeout, "test_timeout": args.test_timeout,
                "build_argv": BUILD, "test_argv": TEST,
                "environment": {key: runner.env.get(key) for key in ["PATH", "CARGO_HOME", "RUSTUP_HOME", "TMPDIR", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "CARGO_PROFILE_DEV_DEBUG", "CARGO_PROFILE_TEST_DEBUG", "PROPTEST_RNG_SEED", "CARGO_TERM_COLOR"]}}
    json_new(output / "source.json", contract)
    runner.report["status"] = "prepared_current_candidates_no_builds"; runner.persist()
    json_new(output / "prepare-report.json", runner.report)
    print("PREPARED", output, [row["candidate"]["name"] for row in selected], flush=True)


def execute(args):
    output = args.prepared.resolve(); contract = json.loads((output / "source.json").read_text())
    root = Path(contract["worktree"]); target = Path(contract["build_target"])
    require(file_sha(Path(__file__)) == contract["runner_sha256"], "runner differs from prepared bytes")
    require((target / ".wave12-owned").read_text() == str(output), "exclusive target ownership differs")
    if contract.get("cache_receipt") is None:
        require({path.name for path in target.iterdir()} == {".wave12-owned"}, "baseline target must still be fresh")
    require(inventory(root) == contract["files"], "source differs from frozen CURRENT inventory")
    runner = Runner(output, root, target, contract["build_timeout"], contract["test_timeout"])
    runner.report["prepared_source_sha256"] = file_sha(output / "source.json")
    runner.report["prepare_report_sha256"] = file_sha(output / "prepare-report.json")
    runner.report["identity"] = contract["identity"]
    require({key: runner.env.get(key) for key in contract["environment"]} == contract["environment"], "execution environment differs from prepared receipt")
    runner.report["environment"] = contract["environment"]
    runner.report["cache_receipt"] = contract.get("cache_receipt")
    sys.path.insert(0, str(root / "tools"))
    sys.dont_write_bytecode = True
    helpers = importlib.import_module("merge_mutation_shards")

    def seeds(label):
        paths = git(root, "ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")
        for name in filter(None, paths):
            require(helpers.proptest_sourceparallel(name, contract["files"]) and helpers.proptest_seed_file(root / name), "unexpected generated input: " + name)
            write_new(output / "generated-seeds" / label / name, (root / name).read_bytes())
            (root / name).unlink()

    try:
        runner.clean("clean-before-baseline")
        baseline = runner.pair("baseline"); runner.report["baseline"] = baseline; runner.persist()
        require(baseline["build"]["exit_code"] == 0 and baseline["test"] is not None
                and baseline["test"]["exit_code"] == 0 and not baseline["test"]["timed_out"], "identical whole-workspace baseline failed")
        baseline_text = (output / baseline["test"]["stdout"]).read_text(errors="replace")
        totals = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;", baseline_text)
        require(sum(int(row[0]) for row in totals) == EXPECTED_BASELINE_PASSED
                and all(int(row[1]) == int(row[4]) == 0 for row in totals), "workspace baseline does not match1003 passed/unfiltered")
        seeds("baseline"); require(inventory(root) == contract["files"], "baseline modified source")
        for selected in contract["selected"]:
            label = selected["label"]; candidate = selected["candidate"]; source = root / candidate["file"]
            require(inventory(root) == contract["files"], "source drift before " + label)
            runner.clean("clean-before-" + label)
            original = (output / "original" / candidate["file"]).read_bytes()
            changed = (output / "mutated" / (label + ".rs")).read_bytes()
            require(sha(original) == selected["original_sha256"] and sha(changed) == selected["mutated_sha256"], "backup or mutation changed")
            source.write_bytes(changed)
            try:
                outcome = runner.pair(label)
                outcome.update(label=label, candidate=candidate["name"], source_before_sha256=sha(original),
                               source_mutated_sha256=sha(changed), producer_diff_sha256=selected["producer_diff_sha256"])
                runner.report["cases"].append(outcome); runner.persist()
            finally:
                require(source.read_bytes() == changed, "external source edit; refusing to overwrite: " + str(source))
                source.write_bytes(original)
                seeds(label)
                require(inventory(root) == contract["files"], "source did not restore after " + label)
                runner.report.setdefault("restores", []).append({"label": label, "source_sha256": file_sha(source), "all_tracked_inputs_restored": True})
                runner.persist(); runner.clean("clean-restored-" + label)
            print("CASE", label, outcome["caught_current_workspace"], flush=True)
        runner.report["status"] = "passed_current_workspace_replays" if all(row["caught_current_workspace"] for row in runner.report["cases"]) else "needs_investigation"
    except BaseException as error:
        runner.report.update(status="interrupted_or_failed", error=repr(error)); runner.persist()
        raise
    finally:
        runner.report["all_tracked_inputs_restored"] = inventory(root) == contract["files"]
        runner.report["ended_at"] = now(); runner.persist()
    require(len(runner.report["cases"]) == 1 and runner.report["status"] == "passed_current_workspace_replays"
            and runner.report["all_tracked_inputs_restored"], "the one CURRENT graph21 workspace replay were not caught and restored")


def main():
    parser = argparse.ArgumentParser(description=__doc__); commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare")
    for option in ("worktree", "output", "build-target", "patch"):
        prep.add_argument("--" + option, type=Path, required=True)
    prep.add_argument("--build-timeout", type=int, required=True); prep.add_argument("--test-timeout", type=int, required=True)
    prep.add_argument("--reuse-from", type=Path, help="Explicit receipt for reusing the completed/restored CURRENT3 wave20 target for graph21")
    run = commands.add_parser("execute"); run.add_argument("--prepared", type=Path, required=True)
    args = parser.parse_args()
    root = args.worktree.resolve() if args.command == "prepare" else Path(json.loads((args.prepared / "source.json").read_text())["worktree"])
    def interrupted(signum, frame):
        raise InterruptedError(f"runner received signal {signum}")
    signal.signal(signal.SIGTERM, interrupted); signal.signal(signal.SIGHUP, interrupted)
    with lock(root):
        if args.command == "prepare":
            require(args.build_timeout > 0 and args.test_timeout > 0, "timeouts must be positive")
            prepare(args)
        else:
            execute(args)


if __name__ == "__main__":
    main()
