Frozen implementation at base f1062073f655c95d98b1d250033ca1495c786ba8.
Only crates/runtime/src/graph.rs structure() changed; no test, policy, evidence, task or numerical executor changes. No Cargo, commit, push or dispatch run by this worker.

Equivalence for all valid or malformed representable RpnOp slices:

1. The old cursor initially selects index zero. The new iterator initially yields index zero with skip_until zero, so it selects the same instruction. For an empty slice both return Ok without a check. Each selected instruction is matched by value exactly as previously: match *op equals match ops[i]. Reference comparisons, their order and returned errors are unchanged.
2. An ordinary selected instruction previously advanced to i+1. The iterator independently advances to i+1. skip_until is either zero or the end of an earlier body and is <= the current index; therefore it cannot skip this next index. Selected non-loop checks and all error ordering remain identical.
3. A selected Loop first checks depth >=2, then checked_add/filter on the same (i+1), body_len and slice length, then calls structure on exactly ops[i+1..end] at depth+1. These operations and their order are byte-for-byte unchanged. If any check or recursion errors, both immediately return the same first error. i+1 is representable for any index in a valid Rust slice; no arithmetic contract changed.
4. On a successful Loop, the old cursor resumed at end. The new skip_until=end suppresses only indices strictly less than end before matching. No reference or depth checks run for these skipped parent indices, so they cannot duplicate validation at an incorrect depth or change error precedence. The next selected parent index is exactly end. For body_len=0, end=i+1 and the next iterator index is immediately selected, preserving empty-body behavior. A zero iteration count still recursively validates the entire stored body because neither version branches on count.
5. By induction on each selected parent instruction and recursive body (depth is bounded), the complete ordered trace of validation checks agrees. This includes malformed lengths/references/depth at any position and mixtures of earlier and later faults. Structure is read-only; successful and failing traces have no additional effects. No errors, allocation, quotas or API semantics were introduced. Whole-graph preflight order, StackBudget, native IEEE execution and checked symbolic evaluation are untouched, so their existing distinction is preserved.

Finite traversal bound:

std slice iteration advances independently of skip_until and every opcode/result. A call always enumerates at most its slice length; skip_until only bypasses match work. Recursive calls occur only at depth<2, so public depth0 preflight visits at most levels0/1/2. Sibling successful body slices are disjoint; malformed overlap cannot be entered because ends are validated within the current slice and the parent suppresses body indices. Each stored opcode is therefore enumerated at most once per level, <=3 total visits. Each opcode is actually matched at its unique owning depth, apart from an early-error prefix. This is a finite O(stored opcodes) structural bound; no wall-clock or inference-performance claim is made. Loop counts do not multiply structural traversal.

Existing useful public oracles, for root to run with pinned1.98.1 --locked:
- cargo test -p bml-runtime --test graph_contracts --locked
  Includes malformed_references_loops_and_stack_effects_fail_before_execution, nested_loops_use_inclusive_work_and_stack_budgets, empty_loop_result_accepts_its_exact_step_budget, single_literal_graph_validation_completes_in_a_bounded_child and external-constant boundaries.
- cargo test -p bml-runtime --test indexed_symbolic_execution --locked
  Includes indexed_symbolic_nested_loops_and_zero_iteration_structure_are_bounded and exact budget/context semantics.
- cargo test -p bml-runtime --test checked_symbolic_execution --locked
- cargo test -p bml-runtime --test graph_rpc_contracts --locked
These existing oracles plus the transition proof suffice for this local rewrite; no redundant test or guard was added to obtain a Caught outcome.

CURRENT mutation proposal for producer (not executed here):
Generate a fresh pinned cargo-mutants listing after root integration, select actual entries whose function is structure, and preserve that listing/candidate identity/source digest before any replay. The historical graph.rs:445 replace += with *= mutation is removed from the current syntax; retain its historical actualTimeout record unchanged rather than relabeling it as Caught. The finite iterator has no manually mutable advancement assignment. The new meaningful boundary is i < skip_until: prioritize actual fresh listed comparison-replacement candidates there and whole-function replacement if listed. Existing malformed/zero-count/depth public graph oracles should independently reject incorrect parent-body traversal. Do not invent candidate IDs/positions or claim a result before a fresh listing and actual outcomes. Keep source, test scope, seeds, flags and timeouts frozen; no other graph loops are in scope.
