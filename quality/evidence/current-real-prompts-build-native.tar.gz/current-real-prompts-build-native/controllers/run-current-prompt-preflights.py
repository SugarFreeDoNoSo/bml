from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/dev/Work/bml')
directory = root / 'target/quality/real-prompts-bbb89735100e'
build_path = directory / 'build-report.json'
build = json.loads(build_path.read_text())
assert build['status'] == 'ready_for_native_preflights'
binary = Path(build['immutable_binary'])
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(binary) == build['immutable_binary_sha256']
output = directory / 'native-preflights.json'
assert not output.exists(), 'preserve previous outputs and observe the recorded process'
report = {'status': 'running_native_only', 'source_revision': build['source_revision'],
          'build_report': str(build_path), 'build_report_sha256': sha(build_path),
          'binary': str(binary), 'binary_sha256': sha(binary),
          'bml_executed': False, 'cases': [],
          'scope': 'Both predeclared native-only prompt preflights; never a full BML result.'}

def persist():
    report['updated_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    output.write_text(json.dumps(report, indent=2) + '\n')

persist()
for prompt, ids in [('Hello', [1, 15043]), ('Hi', [1, 6324])]:
    outdir = directory / ('native-' + prompt.lower())
    assert not outdir.exists()
    log = directory / ('native-' + prompt.lower() + '.log')
    exit_file = directory / ('native-' + prompt.lower() + '.exit')
    env = os.environ.copy()
    env.update(BML_TEST_PROMPT=prompt, BML_TEST_SOURCE_REVISION=build['source_revision'],
               BML_TEST_GGUF=str(root / 'target/bml-1.0/tinyllama/tinyllama-1.1b-chat-v1.0.Q4_0.gguf'),
               BML_TEST_SYMBOLIC_ARTIFACT=str(root / 'target/quality/tinyllama-bounded-two-position32-20'),
               BML_TEST_LOGITS_DIR=str(outdir))
    argv = [str(binary), 'real_model_native_prompt_profile_preflight', '--ignored', '--exact', '--nocapture']
    case = {'prompt': prompt, 'predeclared_ids': ids, 'command': argv, 'output_directory': str(outdir),
            'log': str(log), 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'memory_samples': []}
    report['cases'].append(case)
    with log.open('wb') as stream:
        process = subprocess.Popen(argv, cwd=build['source_worktree'], env=env, stdout=stream, stderr=subprocess.STDOUT)
        case['pid'] = process.pid
        persist()
        while process.poll() is None:
            sample = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'rss_kib': None, 'pss_kib': None, 'mem_available_kib': None}
            try:
                lines = Path(f'/proc/{process.pid}/status').read_text().splitlines()
                sample['rss_kib'] = int(next(line.split()[1] for line in lines if line.startswith('VmRSS:')))
                lines = Path(f'/proc/{process.pid}/smaps_rollup').read_text().splitlines()
                sample['pss_kib'] = int(next(line.split()[1] for line in lines if line.startswith('Pss:')))
            except (OSError, StopIteration, ValueError):
                pass
            try:
                sample['mem_available_kib'] = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))
            except (OSError, StopIteration, ValueError):
                pass
            case['memory_samples'].append(sample)
            persist()
            time.sleep(2)
        case['exit_code'] = process.returncode
    exit_file.write_text(str(case['exit_code']) + '\n')
    case.update(ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log_sha256=sha(log), exit_file=str(exit_file))
    summary = outdir / 'native-preflight-summary.json'
    text = log.read_text()
    case['passed'] = False
    if process.returncode == 0 and summary.exists() and 'test result: ok. 1 passed; 0 failed; 0 ignored;' in text:
        saved = json.loads(summary.read_text())
        case['summary'] = saved
        case['summary_sha256'] = sha(summary)
        case['passed'] = (saved.get('status') == 'native_only_preflight_pass' and saved.get('bml_executed') is False
                          and saved.get('input_ids') == ids and saved.get('prompt') == prompt)
    persist()
    print(prompt, case['exit_code'], case['passed'], flush=True)
assert sha(binary) == build['immutable_binary_sha256']
report['status'] = 'native_preflights_passed' if all(case['passed'] for case in report['cases']) else 'native_preflights_failed'
persist()
raise SystemExit(0 if report['status'] == 'native_preflights_passed' else 1)
