from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import time

root = Path('/home/dev/Work/bml')
directory = root / 'target/quality/real-prompts-bbb89735100e'
build_path, native_path = directory / 'build-report.json', directory / 'native-preflights.json'
build, native = json.loads(build_path.read_text()), json.loads(native_path.read_text())
assert build['status'] == 'ready_for_native_preflights' and native['status'] == 'native_preflights_passed'
assert len(native['cases']) == 2 and all(case['passed'] for case in native['cases'])
binary = Path(build['immutable_binary'])
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(binary) == build['immutable_binary_sha256']
output = directory / 'full-cases.json'
assert not output.exists(), 'do not restart an existing execution; inspect its process and outputs'
native_peak = max(sample['rss_kib'] or 0 for case in native['cases'] for sample in case['memory_samples'])
report = {'status': 'starting_serial_full_cases', 'source_revision': build['source_revision'],
          'build_report': str(build_path), 'build_report_sha256': sha(build_path),
          'native_preflights': str(native_path), 'native_preflights_sha256': sha(native_path),
          'binary': str(binary), 'binary_sha256': sha(binary), 'controller_pid': os.getpid(),
          'concurrency': 1, 'observed_native_peak_rss_kib': native_peak,
          'scope': 'Two current-code fixed prompts, complete saved vectors required; no preset numerical tolerance or performance qualification.',
          'cases': [{'prompt': text, 'input_ids': ids, 'status': 'queued'} for text, ids in [('Hello', [1, 15043]), ('Hi', [1, 6324])]]}

def persist():
    report['updated_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    output.write_text(json.dumps(report, indent=2) + '\n')

def available():
    return int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))

persist()
for case in report['cases']:
    if available() < native_peak + 512 * 1024:
        case['status'] = 'awaiting_memory_unstarted'
        report['status'] = 'needs_memory_before_next_case'
        persist()
        raise SystemExit(2)
    prompt = case['prompt']
    outdir = directory / ('full-' + prompt.lower())
    assert not outdir.exists()
    log = directory / ('full-' + prompt.lower() + '.log')
    samples_path = directory / ('full-' + prompt.lower() + '-resources.jsonl')
    env = os.environ.copy()
    env.update(BML_TEST_PROMPT=prompt, BML_TEST_SOURCE_REVISION=build['source_revision'],
               BML_TEST_GGUF=str(root / 'target/bml-1.0/tinyllama/tinyllama-1.1b-chat-v1.0.Q4_0.gguf'),
               BML_TEST_SYMBOLIC_ARTIFACT=str(root / 'target/quality/tinyllama-bounded-two-position32-20'),
               BML_TEST_LOGITS_DIR=str(outdir))
    argv = [str(binary), 'real_model_two_position_prompt_symbolic_logit_diagnostic', '--ignored', '--exact', '--nocapture']
    case.update(status='running', command=argv, output_directory=str(outdir), log=str(log),
                resources=str(samples_path), started_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                peak_rss_kib=None, peak_pss_kib=None, resource_samples=0)
    with log.open('wb') as stream, samples_path.open('w') as samples:
        process = subprocess.Popen(argv, cwd=build['source_worktree'], env=env, stdout=stream, stderr=subprocess.STDOUT)
        case['pid'] = process.pid
        report['status'] = 'running_serial_full_case'
        persist()
        while process.poll() is None:
            sample = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': process.pid,
                      'rss_kib': None, 'pss_kib': None, 'mem_available_kib': available()}
            try:
                sample['rss_kib'] = int(next(line.split()[1] for line in Path(f'/proc/{process.pid}/status').read_text().splitlines() if line.startswith('VmRSS:')))
                sample['pss_kib'] = int(next(line.split()[1] for line in Path(f'/proc/{process.pid}/smaps_rollup').read_text().splitlines() if line.startswith('Pss:')))
            except (OSError, StopIteration, ValueError):
                pass
            samples.write(json.dumps(sample) + '\n')
            samples.flush()
            for metric in ['rss_kib', 'pss_kib']:
                if sample[metric] is not None:
                    case['peak_' + metric] = max(case['peak_' + metric] or 0, sample[metric])
            case['resource_samples'] += 1
            case['last_memory_available_kib'] = sample['mem_available_kib']
            case['observed_files'] = sorted(path.name for path in outdir.glob('*')) if outdir.exists() else []
            persist()
            time.sleep(15)
        case['exit_code'] = process.returncode
    (directory / ('full-' + prompt.lower() + '.exit')).write_text(str(case['exit_code']) + '\n')
    case.update(ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), log_sha256=sha(log))
    summary = outdir / 'summary.json'
    case['status'] = 'completed_unverified' if process.returncode == 0 and summary.exists() else 'failed_or_incomplete'
    if summary.exists():
        case['summary_sha256'] = sha(summary)
    persist()
    if case['status'] != 'completed_unverified':
        report['status'] = 'stopped_after_failed_case'
        persist()
        raise SystemExit(1)
    assert sha(binary) == build['immutable_binary_sha256']
report['status'] = 'all_cases_completed_unverified'
persist()
