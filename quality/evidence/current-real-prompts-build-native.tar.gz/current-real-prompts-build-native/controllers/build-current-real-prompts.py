from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess

root = Path('/home/dev/Work/bml')
git = lambda *args, cwd=root: subprocess.check_output(['git', *args], cwd=cwd)
revision = git('rev-parse', 'HEAD').decode().strip()
assert re.fullmatch('[0-9a-f]{40}', revision)
assert revision == git('rev-parse', 'origin/master').decode().strip()
directory = root / 'target/quality' / ('real-prompts-' + revision[:12])
worktree = root / 'target' / ('real-prompts-source-' + revision[:12])
target = root / 'target' / ('real-prompts-release-' + revision[:12])
assert not directory.exists() and not worktree.exists() and not target.exists(), 'preserve the existing capture; observe its live handle instead of restarting'
directory.mkdir()
report_path = directory / 'build-report.json'
sha = lambda data: hashlib.sha256(data).hexdigest()

def file_sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def write(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n')

report = {'status': 'creating_clean_checkout', 'source_revision': revision,
          'source_worktree': str(worktree), 'exclusive_build_target': str(target),
          'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'controller_pid': os.getpid(), 'scope': 'Original current-source compilation capture, then ordinary release helper tests only. No model execution or numerical parity claim.'}

def persist():
    report['updated_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write(report_path, report)

persist()
try:
    with (directory / 'checkout.log').open('wb') as log:
        subprocess.run(['git', 'worktree', 'add', '--detach', str(worktree), revision], cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
    assert git('rev-parse', 'HEAD', cwd=worktree).decode().strip() == revision
    assert not git('status', '--porcelain', cwd=worktree).strip()
    paths = [name.decode() for name in git('ls-files', '-z', cwd=worktree).split(b'\0') if name]

    def capture():
        result = {}
        for name in paths:
            path = worktree / name
            if path.is_symlink():
                assert not (name.endswith('.rs') or Path(name).name in {'Cargo.toml', 'Cargo.lock'}), 'compiled symlink needs an explicit capture'
                result[name] = {'kind': 'symlink', 'target': os.readlink(path), 'sha256': sha(os.readlink(path).encode())}
            else:
                result[name] = {'kind': 'file', 'bytes': path.stat().st_size, 'sha256': file_sha(path)}
        return result

    before = capture()
    write(directory / 'source-before.json', before)
    report.update(source_tree=git('rev-parse', 'HEAD^{tree}', cwd=worktree).decode().strip(),
                  tracked_input_count=len(before), source_before=str(directory / 'source-before.json'),
                  source_before_sha256=file_sha(directory / 'source-before.json'))
    env = os.environ.copy()
    pinned = {'CARGO_HOME': '/tmp/bml-cargo', 'RUSTUP_HOME': '/tmp/bml-rustup',
              'CARGO_TARGET_DIR': str(target), 'CARGO_BUILD_JOBS': '1',
              'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_RELEASE_DEBUG': '0',
              'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
              'TMPDIR': str(root / 'target/tool-install-tmp'),
              'RUSTFLAGS': '', 'CARGO_ENCODED_RUSTFLAGS': '',
              'RUSTC_WRAPPER': '', 'RUSTC_WORKSPACE_WRAPPER': ''}
    env.update(pinned)
    env['PATH'] = '/tmp/bml-cargo/bin:' + env.get('PATH', '')
    report['explicit_environment'] = pinned
    report['toolchain'] = {tool: subprocess.check_output(argv, cwd=worktree, env=env, text=True).strip()
                           for tool, argv in [('rustc', ['rustc', '--version', '--verbose']), ('cargo', ['cargo', '--version'])]}
    argv = ['cargo', 'test', '--release', '--verbose', '-p', 'bml-runtime', '--test',
            'real_model_two_position_diagnostic', '--locked', '--no-run', '--message-format=json']
    stdout, stderr = directory / 'cargo-build.jsonl', directory / 'cargo-build.stderr'
    report.update(status='building', command=argv, stdout=str(stdout), stderr=str(stderr),
                  compiler_capture='Original command/environment recorded before launching the compiler; verbose stderr and JSON stdout retained unmodified.')
    with stdout.open('wb') as out, stderr.open('wb') as err:
        process = subprocess.Popen(argv, cwd=worktree, env=env, stdout=out, stderr=err)
        report['cargo_pid'] = process.pid
        persist()
        report['cargo_exit_code'] = process.wait()
    report.update(stdout_sha256=file_sha(stdout), stderr_sha256=file_sha(stderr))
    assert report['cargo_exit_code'] == 0, 'release build failed; preserve this capture'
    after = capture()
    write(directory / 'source-after.json', after)
    assert before == after and not git('status', '--porcelain', cwd=worktree).strip()
    assert git('rev-parse', 'HEAD', cwd=worktree).decode().strip() == revision
    report.update(source_after=str(directory / 'source-after.json'), source_after_sha256=file_sha(directory / 'source-after.json'),
                  source_inputs_unchanged=True)
    rows = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact']
    drivers = [row for row in artifacts if row['target']['name'] == 'real_model_two_position_diagnostic' and row.get('executable')]
    assert len(drivers) == 1 and drivers[0]['fresh'] is False
    wanted = {'bml_domain', 'bml_compiler', 'bml_runtime', 'bml_inference', 'bml_gguf', 'bml_model_weights'}
    numeric = [row for row in artifacts if row['target']['name'] in wanted]
    assert {row['target']['name'] for row in numeric} == wanted and all(row['fresh'] is False for row in numeric)
    original = Path(drivers[0]['executable'])
    assert original.is_relative_to(target)
    immutable = directory / 'real-prompts-measured'
    with original.open('rb') as source, immutable.open('xb') as dest:
        shutil.copyfileobj(source, dest)
    immutable.chmod(0o555)
    assert file_sha(immutable) == file_sha(original)
    report.update(status='checking_release_helpers', driver_artifact=drivers[0], numeric_artifacts=numeric,
                  immutable_binary=str(immutable), immutable_binary_bytes=immutable.stat().st_size,
                  immutable_binary_sha256=file_sha(immutable))
    normal_log = directory / 'release-helper-tests.log'
    normal_argv = [str(immutable), '--nocapture']
    persist()
    with normal_log.open('wb') as out:
        normal = subprocess.run(normal_argv, cwd=worktree, env=env, stdout=out, stderr=subprocess.STDOUT, timeout=360)
    text = normal_log.read_text()
    assert normal.returncode == 0 and 'test result: ok. 3 passed; 0 failed; 3 ignored;' in text
    assert file_sha(immutable) == report['immutable_binary_sha256']
    assert before == capture() and not git('status', '--porcelain', cwd=worktree).strip()
    report.update(status='ready_for_native_preflights', ordinary_release_tests={'command': normal_argv, 'exit_code': normal.returncode,
                  'passed': 3, 'ignored': 3, 'log': str(normal_log), 'log_sha256': file_sha(normal_log)},
                  runner_sha256=file_sha(__file__))
    persist()
    print(json.dumps({'status': report['status'], 'source_revision': revision, 'report': str(report_path), 'binary': str(immutable)}), flush=True)
except BaseException as error:
    report.update(status='failed_capture', error=repr(error))
    persist()
    raise
