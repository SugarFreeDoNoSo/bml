#!/usr/bin/env python3
"""Actual cargo-mutants27.1.0 replay of the exact9 CI candidates, isolated at F."""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import os
import re
import shutil
import signal
import sys

ROOT = Path('/home/dev/Work/bml')
OUTPUT = ROOT / 'target/quality/current-ci-nine-replay-9ff2acd'
WORKTREE = ROOT / 'target/current-ci-nine-replay-9ff2acd'
TARGET = ROOT / 'target/wave-twelve-current-build-20261105T092132Z'
REVISION = '9ff2acd33f9a7fa502254766159caf791cc53d7b'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda name, value: (OUTPUT / name).write_text(json.dumps(value, indent=2) + '\n')
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('recorded_core', OUTPUT / 'core.py')
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)
assert sha(OUTPUT / 'core.py') == '74962ffe28a9c31cc8926d4ae916742f9e62e14e5de3de5fe819f0f6cb895161'
assert not (OUTPUT / 'report.json').exists(), 'preserve previous attempt'
assert core.git(WORKTREE, 'rev-parse', 'HEAD').decode().strip() == REVISION
assert not core.git(WORKTREE, 'status', '--porcelain=v1', '--untracked-files=all').strip()
assert sha(OUTPUT / 'ci-exact.diff') == 'a8575568fe1a5dcdd0d5b470533f96b166ec70e6e87a1017806dbf6150345d19'
assert sha(OUTPUT / 'ci-candidates.json') == '23ac21d34336dac43ba4741f2bab9da75aca50ca2ebafd47bfd7f64ebdd4e7d3'
expected = json.loads((OUTPUT / 'ci-candidates.json').read_text())
assert len(expected) == 9 and len({c['name'] for c in expected}) == 9
before = core.inventory(WORKTREE)
assert len(before) == 864
previous = Path((TARGET / '.wave12-owned').read_text())
old_source = json.loads((previous / 'source.json').read_text())
old_report = json.loads((previous / 'report.json').read_text())
assert old_report['status'] == 'passed_current_workspace_replays' and old_report['all_tracked_inputs_restored']
assert old_report['active'] is None and len(old_report['cases']) == 1
assert all(c['caught_current_workspace'] for c in old_report['cases'])
assert Path(old_source['build_target']) == TARGET and core.inventory(Path(old_source['worktree'])) == old_source['files']
assert len(old_source['files']) == 855
cache = {'previous_output': str(previous), 'previous_source_sha256': sha(previous / 'source.json'),
         'previous_report_sha256': sha(previous / 'report.json'), 'previous_tracked_files': 855,
         'previous_source_restored_verified': True,
         'policy': 'Exclusive target ownership transfer after full old graph21 source verification. Clean runtime/domain/server before workspace baseline and after source restoration; no main build target.'}
for name, digest in before.items():
    path = WORKTREE / name
    backup = OUTPUT / 'source-backup' / name
    backup.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        backup.symlink_to(os.readlink(path))
    else:
        shutil.copy2(path, backup)
    assert hashlib.sha256(os.readlink(backup).encode() if backup.is_symlink() else backup.read_bytes()).hexdigest() == digest
write('source-before.json', {'revision': REVISION, 'tree': core.git(WORKTREE, 'rev-parse', 'HEAD^{tree}').decode().strip(), 'files': before, 'status': ''})
write('cache-receipt.json', cache)
(TARGET / '.wave12-owned').write_text(str(OUTPUT))
runner = core.Runner(OUTPUT, WORKTREE, TARGET, 600, 360)
runner.report.update(scope='Actual cargo-mutants27.1.0 exact9 CURRENT CI replay at clean F; no old timeout reclassification.',
                     revision=REVISION, cache_receipt=cache, tracked_files=864,
                     driver_sha256=sha(Path(__file__)), core_sha256=sha(OUTPUT / 'core.py'),
                     serial_cli='--in-place without --jobs; CARGO_MUTANTS_JOBS and all inherited CARGO_MUTANTS_* removed. Ordinary CI used --jobs2.',
                     original_ci_outcomes_sha256=sha(OUTPUT / 'original-ci-outcomes.json'))
assert not any(key.startswith('CARGO_MUTANTS_') for key in runner.env)
runner.report['environment'] = {key: runner.env.get(key) for key in ['PATH', 'CARGO_HOME', 'RUSTUP_HOME', 'TMPDIR', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'PROPTEST_RNG_SEED', 'CARGO_TERM_COLOR']}
runner.persist()
clean = ['cargo', 'clean', '--locked', '-p', 'bml-runtime', '-p', 'bml-domain', '-p', 'bml-server']
command = ['cargo', 'mutants', '--workspace', '--cargo-arg=--locked', '--test-workspace', 'true',
           '--timeout', '360', '--build-timeout', '600', '--in-place', '--in-diff',
           str(OUTPUT / 'ci-exact.diff'), '--output', str(OUTPUT)]
listing = ['cargo', 'mutants', '--workspace', '--cargo-arg=--locked', '--list', '--json', '--in-diff', str(OUTPUT / 'ci-exact.diff')]
write('execution-plan.json', {'revision': REVISION, 'candidate_names': [c['name'] for c in expected],
                            'listing_argv': listing, 'mutation_argv': command, 'clean_argv': clean,
                            'baseline_build_argv': core.BUILD, 'baseline_test_argv': core.TEST,
                            'workspace_baseline_expected_tests': 1003, 'build_timeout': 600, 'test_timeout': 360,
                            'real_cli_baseline_scope': 'cargo-mutants27.1.0 baseline uses mutated packages; expected bml-runtime, not a whole-workspace baseline.',
                            'jobs_difference': 'Local --in-place serial forbids explicit --jobs. Original ordinary CI used --jobs2.'})

def require_success(row):
    assert row['exit_code'] == 0 and not row['timed_out'], row['label'] + ' failed'

def interrupted(signum, frame):
    raise InterruptedError('driver received signal ' + str(signum))

signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGHUP, interrupted)
try:
    for label, argv in [('rustc-version', ['rustc', '--version', '--verbose']),
                        ('cargo-version', ['cargo', '--version']),
                        ('producer-version', ['cargo', 'mutants', '--version'])]:
        require_success(runner.command(label, argv, 120))
    assert (OUTPUT / 'producer-version.stdout').read_text().strip() == 'cargo-mutants 27.1.0'
    assert (OUTPUT / 'rustc-version.stdout').read_text().startswith('rustc 1.98.1 ')
    listed = runner.command('actual-listing', listing, 120)
    require_success(listed)
    actual = json.loads((OUTPUT / listed['stdout']).read_text())
    assert {c['name']: c for c in actual} == {c['name']: c for c in expected}, 'actual9 listing differs from CI source/spans/diffs'
    assert core.inventory(WORKTREE) == before
    runner.report['actual_listing_matches_exact_ci_nine'] = True
    require_success(runner.command('clean-before-workspace-baseline', clean, 600))
    baseline = runner.pair('workspace-baseline')
    runner.report['workspace_baseline'] = baseline
    runner.persist()
    assert baseline['build']['exit_code'] == 0 and baseline['test'] is not None and baseline['test']['exit_code'] == 0 and not baseline['test']['timed_out']
    totals = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', (OUTPUT / baseline['test']['stdout']).read_text())
    assert sum(int(row[0]) for row in totals) == 1003 and all(int(row[1]) == int(row[4]) == 0 for row in totals)
    assert core.inventory(WORKTREE) == before
    runner.report['workspace_baseline_tests'] = 1003
    runner.persist()
    require_success(runner.command('clean-before-real-cli', clean, 600))
    result = runner.command('actual-cargo-mutants', command, 10800)
    runner.report['actual_cli'] = result
    outcomes_path = OUTPUT / 'mutants.out/outcomes.json'
    assert outcomes_path.exists(), 'actual CLI did not produce outcomes'
    outcomes = json.loads(outcomes_path.read_text())
    candidate_file = OUTPUT / 'mutants.out/mutants.json'
    assert {c['name']: c for c in json.loads(candidate_file.read_text())} == {c['name']: c for c in expected}
    rows = [row for row in outcomes['outcomes'] if isinstance(row['scenario'], dict) and 'Mutant' in row['scenario']]
    assert len(rows) == 9 and {row['scenario']['Mutant']['name'] for row in rows} == {c['name'] for c in expected}
    baselines = [row for row in outcomes['outcomes'] if row['scenario'] == 'Baseline']
    assert len(baselines) == 1
    runner.report['real_cli_baseline'] = baselines[0]
    runner.report['outcomes_counts'] = dict(Counter(row['summary'] for row in rows))
    runner.report['outcomes_sha256'] = sha(outcomes_path)
    runner.report['outcomes_complete'] = bool(outcomes.get('end_time')) and outcomes['total_mutants'] == 9
    runner.report['status'] = ('passed_actual_cli_strict_gate' if runner.report['outcomes_complete']
                               and baselines[0]['summary'] == 'Success' and result['exit_code'] == 0
                               and not result['timed_out'] and all(row['summary'] in ['CaughtMutant', 'Unviable'] for row in rows)
                               else 'completed_actual_cli_gate_not_passed')
    runner.persist()
except BaseException as error:
    runner.report.update(status='replay_failed_or_incomplete', error=repr(error))
    runner.persist()
    raise
finally:
    current = core.inventory(WORKTREE)
    changed = [name for name in before if current.get(name) != before[name]]
    runner.report['tracked_changes_before_restore'] = changed
    for name in changed:
        path = WORKTREE / name
        preserved = OUTPUT / 'changed-inputs-before-restore' / name
        preserved.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, preserved)
        shutil.copy2(OUTPUT / 'source-backup' / name, path)
    sys.path.insert(0, str(WORKTREE / 'tools'))
    import merge_mutation_shards as helpers
    extra = core.git(WORKTREE, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')
    unexpected = []
    for name in filter(None, extra):
        if helpers.proptest_sourceparallel(name, before) and helpers.proptest_seed_file(WORKTREE / name):
            path = OUTPUT / 'generated-seeds' / name
            path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(WORKTREE / name, path)
            (WORKTREE / name).unlink()
        else:
            unexpected.append(name)
    restored = core.inventory(WORKTREE)
    clean_status = core.git(WORKTREE, 'status', '--porcelain=v1', '--untracked-files=all').decode()
    runner.report.update(all_tracked_inputs_restored=restored == before,
                         source_clean_after=clean_status == '', unexpected_untracked_inputs=unexpected)
    write('source-after.json', {'revision': REVISION, 'files': restored, 'status': clean_status})
    require_success(runner.command('clean-after-source-restoration', clean, 600))
    runner.report['ended_at'] = core.now()
    runner.persist()
    assert restored == before and clean_status == '' and not unexpected, 'source did not fully restore'
print('COMPLETED', runner.report['status'], runner.report.get('outcomes_counts'), flush=True)
