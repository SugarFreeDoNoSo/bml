"""Local process-only TERM probe; always kills its disposable session members."""
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import textwrap
import time

root = Path.cwd()
old = subprocess.check_output(['git', 'show', 'HEAD:.github/workflows/mutation-campaign.yml'], text=True)
new = (root / '.github/workflows/mutation-campaign.yml').read_text()

def members(pid):
    return subprocess.run(['ps', '--sid', str(pid), '-o', 'pid=,ppid=,pgid=,stat='],
                          capture_output=True, text=True).stdout

for name, workflow, marker in [('old-foreground', old, '          if timeout --signal=TERM'),
                               ('new-background', new, '          timeout --signal=TERM')]:
    start = workflow.index(marker)
    end = workflow.index('          df -h . > "$evidence/disk-after.txt"', start)
    shell = textwrap.dedent(workflow[start:end])
    with tempfile.TemporaryDirectory() as temporary:
        evidence = Path(temporary)
        (evidence / 'run-shard.sh').write_text('printf ready > "$evidence/ready"\nsleep 360\n')
        output = (evidence / 'stdout').open('w')
        proc = subprocess.Popen(['bash', '-e', '-o', 'pipefail', '-c', shell], cwd=root,
                                env={**os.environ, 'evidence': str(evidence)},
                                stdout=output, stderr=output, start_new_session=True)
        try:
            deadline = time.monotonic() + 5
            while not (evidence / 'ready').exists():
                assert time.monotonic() < deadline
                time.sleep(0.01)
            time.sleep(0.1)
            print(name, 'shell=', proc.pid, 'BEFORE', members(proc.pid), sep='\n', flush=True)
            os.kill(proc.pid, signal.SIGTERM)
            time.sleep(0.3)
            print('shell return=', proc.poll(), 'AFTER', members(proc.pid), sep='\n', flush=True)
        finally:
            for row in members(proc.pid).splitlines():
                try:
                    os.kill(int(row.split()[0]), signal.SIGKILL)
                except ProcessLookupError:
                    pass
            proc.wait(timeout=5)
            output.close()
