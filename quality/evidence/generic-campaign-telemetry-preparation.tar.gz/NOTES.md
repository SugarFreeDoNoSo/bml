Frozen implementation handoff; no commit, push, Cargo invocation or dispatch by this worker.

Base: f1062073f655c95d98b1d250033ca1495c786ba8
Worktree: /home/dev/Work/bml/target/wave-nineteen-campaign-telemetry

Changed: .github/workflows/mutation-campaign.yml and new tools/test_mutation_campaign.py only.

The unchanged timeout/bash runner is backgrounded under its own PID with stdout/stderr exclusively redirected to runner.log. The existing generic mutation_subshards.py telemetry CLI monitors this PID's real descendant tree, writes telemetry.jsonl and flushes bounded JSON to workflow stdout every 30 seconds. It is outside runner.log. Conditional wait preserves the runner's exit status before monitor cleanup; EXIT trap kills and reaps the monitor on intervening shell failure. There is no tee or added runner pipeline. Existing timeout, argv, source, sealing, outcome cases and global gate are untouched. Telemetry interpretation and implementation are untouched, including missing metrics as null and unknown active mutant.

Behavioral integration test extracts and runs the actual workflow launch/wait/cleanup fragment under Bash errexit/pipefail with a small real runner and the real generic telemetry CLI. Only the test monitor interval is shortened. The child waits for a release marker: a test wrapper calls the real diagnostic_sample and notes the child PID; the sleep wrapper releases the child only after telemetry has flushed that sample to file/stdout. This avoids startup and output-flush scheduling races. Exit 0/2/3/124/143 statuses are retained; actual child PID appears in telemetry; runner log retains exact stdout/stderr bytes without telemetry; stdout equals JSONL file; samples meet 32KiB bound; runner and monitor are reaped. Existing bounded-output/proc/privacy unit tests remain authoritative for telemetry interpretation.

Verification: python3 -m unittest discover -s tools -p 'test_*.py': 236 tests passed (see latest python-tests.log), log python-tests.log. /home/dev/Work/bml/target/actionlint-1.7.12/actionlint .github/workflows/mutation-campaign.yml: passed, empty actionlint.log. git diff --check: passed. No Cargo or Rust changes.

Self-review: timeout PID is an ancestor of the bash runner and cargo tree, not a log copier. Conditional wait prevents errexit from skipping cleanup for nonzero runner status. Monitor errors remain diagnostic-only, matching the preexisting nested monitor treatment; they cannot change runner status or authorize a seal. No candidate, seed, timeout, memory policy, frozen historical evidence, quality policy or task ledger changed. Main and user-owned documents untouched.

TERM interruption comparison: term-probe.py/.log signal only the outer Bash PID while its inert runner sleeps. BOTH the original foreground shell and the proposed background shell exit with -15 and leave the existing timeout/bash/sleep subtree alive. The new monitor is cleaned up by EXIT trap. Thus outer-shell-only TERM can orphan the runner in the existing workflow too; this patch preserves that signal behavior and does not claim a cancellation guarantee. Probe cleanup kills its disposable session members. Root explicitly requested retaining this minimal production scope rather than adding a new trap/protocol.

Initial freeze patch/logs/notes are preserved under initial-freeze/.
