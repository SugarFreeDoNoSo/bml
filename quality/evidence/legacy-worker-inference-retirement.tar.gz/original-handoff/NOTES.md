Frozen legacy worker retirement, base9ff2acd33f9a7fa502254766159caf791cc53d7b.
Worktree: /home/dev/Work/bml/target/wave-twenty-two-legacy-worker-retirement
Only crates/worker/src/main.rs changed. No Cargo, commit, push, dispatch, task edits or main edits.

Requirement: fix-placeholders8.5.8 explicitly identifies historical RMS/Q-only worker and requires complete causal instruction/weight/session/coverage behavior;8.5.9 requires auditing the actual consumer. This patch retires that incomplete inference rather than claiming its replacement by an unused API. The root explicitly authorized preserving legacy fragment admission, upload validation and ACK semantics separately from inference.

Behavior: every legacy BatchRequest returns the existing empty BatchResult rejection frame and logs migration to --symbolic-artifact or --prepared. The same TCP connection remains available for health/other supported commands. There is no dimension decode, weight execution or partial result. The dead private RMS/Q executor was removed. --fragment help and module protocol documentation identify compatibility admission; ExecuteFragment remains ACK-only admission. Legacy decoder/shapes/files/queue/steal, graph/vector work and modern symbolic startup/protocol are unchanged. Modern startup byte comparison (excluding allowed help/docs) and graph/health/queue/steal handler comparisons pass. No new limits/errors/opcodes were introduced; valid legacy-inference callers intentionally receive existing rejection rather than old partial output.

Regression contract: legacy_batch_tcp_rejects_valid_inference_without_disabling_health uploads a two-dimensional finite RMS/Q fragment, independently encodes [1,2] input, checks successful upload ACK, empty inference result and subsequent health response. On the old executor these weights/input yielded [7,10]/sqrt(2.5+1e-5), so rejection cannot be mistaken for malformed input or absent admission. No positive numerical result from that retired path remains. invalid_legacy_shard_upload_preserves_loaded_model_and_other_connections now checks health plus unchanged admitted identity/weights instead of requesting retired inference; malformed upload still returns NaN ACK and closes only its connection. Shape/file/sparse tests retain admission checks after removing assertions against the deleted private executor.13 binary unit tests remain13.

Renamed tests (all were absent from quality/traceability.json, so no existing mapping is dangling):
- legacy_batch_tcp_validates_dimensions_and_exact_payload_length -> legacy_batch_tcp_rejects_valid_inference_without_disabling_health
- legacy_shard_preflight_rejects_unsafe_shapes_before_execution -> legacy_shard_preflight_rejects_unsafe_shapes_before_admission
- legacy_sparse_layers_preserve_order_without_visiting_empty_layer_ranges -> legacy_sparse_metadata_admission_does_not_visit_empty_layer_ranges
Other adjusted names retained: invalid_legacy_shard_upload_preserves_loaded_model_and_other_connections; legacy_file_loading_restores_config_and_applies_shape_preflight.

Root verification proposal (not run by worker):
cargo test -p bml-worker --bin bml-worker --locked
cargo test -p bml-worker --test symbolic_worker_contracts --locked
cargo test -p bml-cli --test symbolic_distributed_cli --locked
Then canonical integration gate and trace check. Existing positive modern C103 target includes pipeline_covers_all_layers_on_one_two_or_extra_worker_processes with bitwise logits, range coverage, max_nodes0, reset and extra idle worker; C104 CLI target covers bytes/relocated weights/EOS. C105 compiler retirement remains untouched. Do not map this binary-unit regression into C103's integration target without a separate package/target mapping; root may add a dedicated contract if desired.

Checks actually performed: pinned rustfmt1.98.1 --edition2021 --config skip_children=true on changed file; git diff --check; unchanged-handler/startup comparisons; old/new test count and renamed-unmapped mapping inspection. No compiled/test result claimed. Parent report current-g1-consumer-audit-9ff2acd records static audit; global8.5.8/8.5.9, hosts and model obligations remain open. Partial-reset fault regression is a separate optional proposal, outside this patch.
