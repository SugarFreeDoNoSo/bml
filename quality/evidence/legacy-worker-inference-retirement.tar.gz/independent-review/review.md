# Revisión independiente: retirada del worker legacy

Dictamen: **patch fuente aprobado**, con actualización documental requerida al integrar. No se hallaron defectos bloqueantes de código. Revisión estática, sin Cargo ni ejecución de pruebas.

- Base: `9ff2acd33f9a7fa502254766159caf791cc53d7b`.
- Patch SHA-256: `723bb05bf767a16826ee52996700b663429fc138d8e8bd7d0d172c9b48c53f09`.
- `crates/worker/src/main.rs` candidato SHA-256: `c75f242ab108ff7ef8682ea1320ff9d4b4936fbfa722a54c5546e9a3812cfd80`.
- El patch se reprodujo en memoria contra la base y coincide exactamente con el archivo candidato. Sólo cambia `crates/worker/src/main.rs`.

## Comportamiento y consumidores

El handler deja de ejecutar RMS/Q y devuelve siempre el rechazo existente, `BatchResult` tipo 5 con payload vacío. La recepción sigue limitada por el framing existente; su fallo cierra la conexión. Tras recibir un frame batch completo, el rechazo permite seguir usando la conexión y un fallo de escritura termina el handler. Los mensajes batch mal dimensionados ya no siguen la antigua validación/cierre: también se rechazan como inferencia retirada. El diagnóstico local dirige a `--symbolic-artifact` o `--prepared`.

No hay consumidor Rust contemporáneo de batch fuera de la implementación/tests del worker y las definiciones del protocolo. `NodeHandle` no ofrece un método batch. La CLI distribuida usa `SymbolicLayerClient`/`SymbolicPipeline`; ambos compiladores distribuidos históricos ya rechazan. Esta búsqueda no acredita corrección por ausencia de callers: la retirada es explícita y el test usa entrada válida que antes ejecutaba el resultado parcial. Los clientes raw externos siguen siendo una superficie pública y reciben el rechazo en lugar de valores parciales.

El cuerpo de `main` es idéntico salvo la ayuda legacy. Se conservaron `--prepared`, artefactos, autenticación, límites y sesiones causales. El handler es idéntico fuera del brazo batch y un comentario de ACK. Se conservan health, graph/vector, cola, robo, carga/ACK y error de upload. La región serializer/decoder es idéntica.

## Pruebas y trazabilidad

El nuevo test TCP carga un shard válido de una capa con dimensión 2, pesos RMS finitos y matriz Q no trivial; comprueba ACK exacto `1.0`, envía `[1,2]` con longitud/dimensión correctas, exige rechazo vacío y comprueba health en la misma sesión. El antiguo ejecutor devolvería `[7,10]/sqrt(2.5+1e-5)`, de modo que restaurarlo rompe la aserción. El cliente fija plazos de lectura/escritura de dos segundos y se descarta antes de `join`, permitiendo EOF al servidor en el camino exitoso. No constituye una prueba general de tiempo máximo ante mutaciones arbitrarias.

Los tests de admisión preservan formas inválidas, rangos de almacenamiento, carga de archivo, truncamientos y conteos. La prueba de upload rechazado ahora inspecciona id/pesos retenidos en lugar de ejecutar inferencia retirada. Se retiran sólo expectativas numéricas del ejecutor RMS/Q eliminado; no se tocan contratos modernos. Los tres nombres renombrados no aparecen en `quality/traceability.json`; C68 enlaza pruebas del compiler, no estas pruebas unitarias. No se ejecutó el comando de trazabilidad.

## Observación de integración DOC-1

`docs/QUALITY.md:331-348` y `crates/runtime/src/net.rs:14-15,34` todavía describen aceptación de batch, dimensiones y el antiguo test. `openspec/changes/bml-implementation-plan/tasks.md:64` cita el test retirado; `openspec/changes/bml-inference-pipeline/tasks.md:58` dice que `execute_layers` sigue parcial. Root confirmó que corregirá textos vigentes/comandos al integrar. Las evidencias `worker-batch-protocol.json` y `legacy-shard-loading.json` deben permanecer históricas e íntegras, con referencia nueva que delimite el comportamiento actual.

## Límites

No se ejecutaron Cargo, tests, gate, mutaciones, red, modelos ni hosts; la verificación dinámica serializada corresponde a root. La retirada no acredita inferencia completa, hosts reales, modelos grandes ni rendimiento. `fix-placeholders` 8.5.8 y 8.5.9 permanecen abiertas. El detalle de comprobaciones y hashes de entradas está en `review.json`.
