# Nueva campaña completa del código actual

Recomendación: terminar la regresión18 y sus gates, congelar un SHA final **F**, añadir antes de congelarlo telemetría acotada al workflow si root aprueba ese cambio, y ejecutar **64 shards** del diff completo contra `40b3f1be2d3f97028b741750ed61ab72f501a555`. No hace falta modificar las restricciones históricas de los helpers de recuperación9a. No se ha ejecutado Cargo, preparado un nuevo manifiesto ni enviado un dispatch en esta auditoría.

La auditoría empezó sobre `6910c359`; al guardar el plan HEAD era `e25fb8e9448bcb88ba2fc65027c272772854f708`. `bml_matrix.rs` y trazabilidad todavía tenían cambios de la regresión18. **F aún no está fijado**. El checkout utilizado para preflight/manifest debe estar limpio en F; los cambios ajenos que permanezcan en main no deben incorporarse automáticamente a la congelación.

## Frontera observada de las cinco recuperaciones

Las cinco ejecuciones frescas de 29/31/39/40/43 terminaron en `failure` durante `Run only the original frozen shard and its baseline`. En todos los logs hay exit 143 y señal de apagado del runner. Autorización y plan habían pasado; attestation, finish y upload quedaron **skipped**. Cada inventario API contiene exactamente **cero artifacts**. Los inputs runtime de las cinco ejecuciones sí se comprobaron contra sus logs.

No hay raw fresco, baseline observable, progreso ni candidato activo recuperable. Se retuvieron los 81 candidatos **planificados** de cada índice; esos 405 candidatos asignados no son resultados ejecutados. No hay una excepción CLI/schema observada que justifique parchear el controlador. La causa de los apagados sigue **UNKNOWN**, sin evidencia de OOM. La unión histórica sigue en 58.

Informe y hashes: `target/quality/recovery-first-five-6910c359/terminal-audit-20261105T110733Z/five-terminal-failure-report.json`, SHA256 `050497a262cd850b01ebdf205e34734deff12a32a14815c6bc3155557b9ef868`. Conserva jobs, logs, check-runs, anotaciones, inventarios y asignaciones. No se recomienda otro retry ciego, incluido parent20.

## Ruta genérica disponible

`mutation-campaign.yml` congela `${{ github.sha }}` y prepara el diff completo contra la base40b3. `merge_mutation_shards.py` acepta cualquier revisión válida con esa base; `mutation_actions.py` comprueba el SHA del workflow y el digest del archivo del manifiesto entregado por prepare. Estas rutas normales no llaman al autorizador de recovery9a ni necesitan sus constantes.

Se mantienen Rust1.98.1, cargo-mutants27.1.0, semilla20260923, dos jobs de compilación, `--workspace`, `--cargo-arg=--locked`, `--test-workspace true`, `--in-place`, timeout360, build-timeout600 y round-robin. El baseline real de cada shard prueba los paquetes seleccionados por cargo-mutants; **cada mutante** se prueba contra todo el workspace. No debe describirse ese baseline como un baseline adicional de todos los paquetes.

El número de candidatos actual debe listarse. Los5183 candidatos de9a no fijan el universo de F. Prepare ya lista el universo y cada `i/64` por separado, exige la partición exacta sin duplicados/huecos y vuelve a comprobar el checkout y el diff. El listado global omite `--sharding`; cada listado de shard lleva tanto `--sharding round-robin` como `--shard i/64`.

La recolección SourceParallel corregida ya está en el sealer genérico actual. No hace falta usar la atestación de fallback del controlador9a en la campaña normal de F. Los estados2/3 conservan sello y raw completo antes de llegar al gate estricto.

## 64 frente a128

| Opción | Soporte actual | Presupuesto con8 slots | Decisión |
|---|---|---|---|
|64|Input permitido; valor predeterminado|40h con deadlines de300min;44h con jobs de330min, más prepare/colas/aggregate|Usar. La retención de72h sigue necesitando margen de cola y descarga oportuna.|
|128|El helper permite N no vacío; el workflow no ofrece128|80h con deadlines;88h con jobs completos, antes de colas/setup|No usar con la retención actual de3d. Requiere cambio explícito de input y retención/colección; duplica baselines y no garantiza reducir cómputo total.|

No aumentar límites de memoria ni reclasificar kills como caught para cerrar resultados. Los límites temporales y el score se conservan. El timeout real de un mutante sigue siendo Timeout y hace fallar el gate.

Con 128 shards, jobs y artifacts de plan/shards/aggregate superan 100 registros. La auditoría independiente tendría que retener todas las páginas API y comprobar la unión de IDs; no puede reutilizar un lector de la campaña de 64 que exige una sola página completa. Esa verificación adicional también forma parte de cualquier propuesta de 128.

## Concurrencia y diagnóstico

`max-parallel:8` sólo limita la matriz de ese workflow. Los grupos de concurrency de campaña completa, quality y recovery son distintos: cinco recoveries activas más ocho shards habrían sido13 jobs, sin contar quality. Ahora las cinco ya son terminales; las consultas activas capturadas en `inputs/` devolvieron0 runs in_progress y0 queued. Hay que repetir el inventario **justo antes** de cualquier dispatch futuro, porque un push inicia hasta tres jobs ordinarios.

Secuencia recomendada: terminar/publicar F y esperar sus jobs de quality; cuando quepan ocho jobs, ejecutar prepare1 → shards≤8 → aggregate1. Evitar otros jobs hosted mientras la matriz usa ocho. El workflow no aporta un semáforo global. Si se necesita solapar cinco jobs, hace falta una decisión nueva y validada de `max_parallel≤3`; modificar un archivo después del dispatch no cambia la matriz congelada.

El workflow completo actual redirige el runner a `runner.log` y carece de telemetría stdout. Los cinco fallos demuestran la pérdida de artifacts cuando el host desaparece. Un cambio pequeño de workflow puede reutilizar el CLI genérico `mutation_subshards.py telemetry` sin modificar sus rutas9a: PID del runner real, JSON≤32KiB a stdout y archivo cada30s, allowlist de RSS/cgroup/events/disk y metadatos del log más reciente. Su ruta telemetry no valida SOURCE9a. La identidad del snapshot actual vendría del workflow/job API y del checkout F.

El stdout de telemetría debe quedar fuera de `runner.log`; conservar exactamente el código del runner y las banderas existentes. Métricas ausentes quedan null, `active_mutant` permanece unknown y no se leen argv/env ni contenido de logs. Este dato es diagnóstico: ni un RSS alto ni exit143 identifican por sí solos OOM o el mutante responsable. No sustituye un sello de fuente.

## Preflight y congelación

1. Completar/revisar regresión18 y preservar Liveness12/14/16 y contratos de metadatos. Publicar F y guardar hashes de fuentes, toolchain y políticas. Si se añade telemetría, integrarla antes de elegir F.
2. Acreditar el gate canónico sobre exactamente esos inputs: formato del delta revisado,235 pruebas Python actuales, workspace tests, auditoría0, trazabilidad y Clippy sin nuevos diagnósticos. Si root ya tiene el gate final y sus hashes coinciden, no repetirlo por rutina.
3. Obtener cobertura y features aplicables sobre F. `prepare` ya ejecuta GGUF sin features y con todas las features; no duplicar ese mismo trabajo local si se conserva su evidencia de F. Mantener la matriz aplicable de fachada/runtime/kernels y ejecutar los modelos Loom reales del snapshot final. Los comandos previstos están en `commands-planned.json`.
4. Validar OpenSpec con la instalación aprobada. El CLI no está en el PATH de este agente; se consultaron los tasks directamente y no se instaló software ni se afirmó una nueva validación.
5. Retener branch-HEAD API, solicitud con argv/timestamp y runs-before. Enviar **un** dispatch cuando master apunte a F y el presupuesto lo permita; autenticar el único ID nuevo y su repo/workflow/event/attempt1/headF. Si no coincide con F, no mezclarlo con la congelación aprobada ni enviar otro dispatch automático.
6. Prepare calcula manifiesto nuevo con la misma base40b3 y transmite su digest por output independiente. Guardar manifest+diff y asignaciones completas antes de considerar cualquier shard.

## Verificación de resultados y criterio final

Cada shard debe tener API/job/artifact del run e intento elegidos, ZIP auténtico por digest, fuente F exacta, candidatos asignados exactos, baseline Success real, raw completo y timestamps dentro de su ejecución. Comparar los SHA de raw con el sello y verificar todas las semillas SourceParallel, sus bytes y el inventario exacto. `mutation_actions.merge_directory` valida los objetos sellados y la unión, pero no abre por sí solo cada archivo raw descargado: conservar también la auditoría independiente de bytes/API/ZIP.

El agregado necesita exactamente64 resultados de ese manifiesto; conserva todos los baselines reales y un baseline agregado correcto. El gate actual exige **cero missed y cero timeouts**, sin exclusiones semánticas aprobadas. Unviable se reporta aparte. Los artifacts y el aggregate deben conservarse también cuando el score falla.

Los artefactos9a, sus recoveries y los envelopes de parent20 no pueden entrar en el agregado F: fuente, manifiesto, universo de candidatos y patrón run/attempt son diferentes. Los helpers de recovery están fijados a9a y no sirven para recuperar F; no cambiar sus constantes para hacerlo. Un fallo nuevo requiere revisar un protocolo fresco ligado a F o repetir el workflow entero. Reintentar sólo jobs fallidos puede carecer del plan específico del nuevo attempt.

## Cobertura, CI y límites del cierre

El run [42012184765](https://github.com/SugarFreeDoNoSo/bml/actions/runs/42012184765) pasó sus tres jobs sobre `6910c359`. El ZIP de cobertura se verificó por API/digest: **90.4835535564% líneas y81.6223977028% funciones**, sobre pisos52/60. Es cobertura ordinaria del workspace: no ramas, doctests ni tests ignorados de modelos. La mutación ordinaria del mismo run fue **N/A**, diff del último push vacío,0 candidatos y0 baselines; no cubre la campaña completa contra40b3.

Ese CI contiene el código productivo de Liveness12/14/16, pero no la regresión18 pendiente ni una medición automática de F futuro. Los informes de cobertura9efc922/63b60ee y los diez modelos Loom de9a siguen siendo evidencia de sus fuentes, no de F por cambio de etiqueta. El último gate local de waves acreditó1002Rust/235Python y115/115 sobre sus inputs; el gate final de root debe superarlo o probar identidad exacta de los inputs finales.

Los tamaños históricos del hot loop, los tests funcionales y los replays no establecen PMU/L1i ni rendimiento del Runtime final. Código máquina y campaña PMU con el driver real deben corresponder al binario/fuentes actuales;5.3/5.10 continúan pendientes de VM/PMU/cloud y no se cierran con mutaciones. Los modelos Loom acotados tampoco prueban todos los interleavings de Runtime.

Conservar9a como dataset histórico **incompleto y obsoleto**:58/64 completos; faltan20/29/31/39/40/43. Ni58 ni un hipotético63/64 satisfacen el gate. Preservar raw auténtico, ZIPs, API, hashes, missed y timeouts; no convertir una muerte por recursos en caught ni archivar el change OpenSpec como completo. La tarea6.2 sigue abierta hasta que el código actual obtenga la campaña completa y el gate estricto.

Referencias de código con líneas y SHA256, snapshots primarios y comandos previstos: `references.json`, `restart-plan.json`, `commands-planned.json`. Todas las salidas de esta auditoría están en `target/`; no se ha modificado main, workflows, políticas o baselines.
