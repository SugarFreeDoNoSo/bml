#!/usr/bin/env python3
"""Offline validation of one already-downloaded fresh46 artifact; no Cargo/API."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path('/home/dev/Work/bml')
sys.path.insert(0, str(ROOT / 'tools'))
import mutation_recovery as recovery
import mutation_subshards as nested
from merge_mutation_shards import (
    digest, file_digest, proptest_seed_file, proptest_sourceparallel,
    read_json, require, timestamp, validate_v1_result,
)

DIRECTORY = Path(__file__).resolve().parent
RUN = 42002319364
JOB = 127160327341
CONTROLLER = '9c3e5f36d6721a0733b97e97db50f9a094f5508e'
INDEX = 46
SHARD = '46/64'


def main():
    run = read_json(DIRECTORY / 'run.json')
    jobs = read_json(DIRECTORY / 'jobs.json')
    inventory = read_json(DIRECTORY / 'artifacts.json')
    artifact = read_json(DIRECTORY / 'artifact-api.json')
    require(run['id'] == RUN and run['head_sha'] == CONTROLLER
            and run['run_attempt'] == 1 and run['event'] == 'workflow_dispatch'
            and run['path'] == '.github/workflows/mutation-recovery.yml'
            and run['repository']['full_name'] == recovery.REPOSITORY
            and run['repository']['id'] == recovery.REPOSITORY_ID
            and run['head_repository']['id'] == recovery.REPOSITORY_ID
            and run['status'] == 'completed' and run['conclusion'] == 'success', 'wrong completed recovery run')
    require(jobs['total_count'] == len(jobs['jobs']) == 1, 'missing or extra recovery job')
    job = jobs['jobs'][0]
    require(job['id'] == JOB and job['run_id'] == RUN and job['run_attempt'] == 1
            and job['head_sha'] == CONTROLLER and job['name'] == 'recover'
            and job['status'] == 'completed' and job['conclusion'] == 'success', 'wrong completed recovery job')
    require(inventory['total_count'] == len(inventory['artifacts']) == 1
            and inventory['artifacts'][0] == artifact
            and artifact['name'] == f'mutation-recovery-{recovery.ORIGIN_RUN}-{RUN}-1-{INDEX}'
            and artifact['expired'] is False and artifact['workflow_run']['id'] == RUN
            and artifact['workflow_run']['head_sha'] == CONTROLLER
            and artifact['workflow_run']['repository_id'] == recovery.REPOSITORY_ID
            and artifact['workflow_run']['head_repository_id'] == recovery.REPOSITORY_ID,
            'wrong or ambiguous API recovery artifact')
    blob = (DIRECTORY / 'artifact.zip').read_bytes()
    require(artifact['digest'] == 'sha256:' + hashlib.sha256(blob).hexdigest()
            and artifact['size_in_bytes'] == len(blob), 'artifact ZIP differs from immutable API digest/size')
    _, names = recovery.zip_members(blob, set())
    destination = DIRECTORY / 'extracted'
    require(not destination.exists(), 'extraction destination already exists')
    control_prefix = 'control/target/quality/recovery/'
    plan_prefix = 'source/target/quality/original-plan/'
    evidence_prefix = f'source/target/quality/shard-{INDEX}/'
    raw_prefix = f'source/target/final-mutation-shard-{INDEX}/mutants.out/'
    seed_paths = []
    with zipfile.ZipFile(DIRECTORY / 'artifact.zip') as archive:
        manifest = recovery.checked_plan_bytes(archive.read(plan_prefix + 'campaign.json'),
                                              archive.read(plan_prefix + 'final.diff'), SHARD)
        for name in names:
            if name.endswith('/'):
                continue
            relative = name.removeprefix('source/')
            seed = (name.startswith('source/') and
                    ('.proptest-regressions' == Path(name).suffix
                     or ('proptest-regressions' in Path(name).parts and name.endswith('.txt'))))
            if seed:
                require(relative in manifest['source']['files']
                        or proptest_sourceparallel(relative, manifest['source']['files']), 'foreign seed path')
                seed_paths.append(relative)
            require(name.startswith((control_prefix, plan_prefix, evidence_prefix, raw_prefix))
                    or name in {f'source/target/quality/shard-result-{INDEX}.json',
                                f'source/target/quality/controller-shard-result-{INDEX}.json'} or seed,
                    'ZIP path outside evidence or declared SourceParallel inputs')
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(name) as incoming, target.open('xb') as output:
                shutil.copyfileobj(incoming, output, length=1024 * 1024)
    control = destination / control_prefix
    source = destination / 'source'
    evidence = destination / evidence_prefix
    raw = destination / raw_prefix
    authorization = recovery.authorization(control)
    require(authorization['format_version'] == 2 and authorization['index'] == INDEX
            and authorization['shard'] == SHARD and authorization['origin_job_id'] == 126992343007
            and authorization['recovery_run_id'] == RUN and authorization['recovery_attempt'] == 1
            and authorization['controller_revision'] == CONTROLLER
            and authorization['source_revision'] == recovery.SOURCE
            and authorization['eligibility_state'] == 'retry_eligible_from_api_bound_collection_failure'
            and authorization['fresh_execution_required'] is True, 'wrong v2 authorization/input identity')
    metadata = read_json(control / 'recovery-metadata.json')
    require(metadata['format_version'] == 1 and metadata['authorization'] == authorization
            and metadata['status'] == 'complete_sealed_shard'
            and metadata['campaign_manifest_sha256'] == manifest['manifest_sha256'], 'incomplete recovery metadata')
    code = int((evidence / 'exit-code.txt').read_text())
    sealer = read_json(evidence / 'sealer-info.json')
    require(metadata['runner_exit_code'] == sealer['runner_exit_code'] == code
            and sealer['source_revision'] == recovery.SOURCE
            and sealer['controller_revision'] == CONTROLLER and metadata['sealer'] == sealer,
            'sealer provenance or exit differs')
    if code in {0, 2, 3}:
        relative_seal = f'target/quality/shard-result-{INDEX}.json'
        require(sealer['method'] == 'frozen-9a-sealer'
                and sealer['sealer_tool_sha256'] == manifest['source']['files']['tools/merge_mutation_shards.py']
                and metadata['cargo_mutants_exit_code'] == code
                and (source / relative_seal).read_bytes() == (evidence / 'final-source-seal.json').read_bytes(),
                'frozen seal/final source recheck differs')
    else:
        relative_seal = f'target/quality/controller-shard-result-{INDEX}.json'
        controller_tool = subprocess.check_output(['git', 'show', CONTROLLER + ':tools/merge_mutation_shards.py'], cwd=ROOT)
        require(code == 1 and metadata['cargo_mutants_exit_code'] is None
                and sealer['method'] == 'controller-live-source-sealer'
                and sealer['sealer_tool_sha256'] == hashlib.sha256(controller_tool).hexdigest()
                and not (source / f'target/quality/shard-result-{INDEX}.json').exists()
                and (evidence / 'runner.log').read_text().rstrip().splitlines()[-1] == recovery.UNTRACKED_ERROR,
                'controller seal is not the distinct narrow exit1 live-source attestation')
    seal_path = source / relative_seal
    seal = read_json(seal_path)
    require(metadata['seal_relative_path'] == relative_seal
            and metadata['shard_result_sha256'] == sealer['seal_sha256'] == file_digest(seal_path), 'seal file hash differs')
    baseline, mutations = validate_v1_result(manifest, seal)
    outcomes = read_json(raw / 'outcomes.json')
    candidates = read_json(raw / 'mutants.json')
    require(seal['shard'] == SHARD and seal['outcomes'] == outcomes and seal['candidates'] == candidates
            and len(candidates) == len(mutations) == outcomes['total_mutants'] == 81
            and seal['outcomes_sha256'] == digest(outcomes), 'raw, seal or assigned81 candidates differ')
    artifacts = seal['artifacts']
    require(artifacts['outcomes_json_sha256'] == metadata['raw_outcomes_sha256'] == file_digest(raw / 'outcomes.json')
            and artifacts['mutants_json_sha256'] == metadata['candidates_sha256'] == file_digest(raw / 'mutants.json'),
            'raw file SHA differs from controller metadata/seal')
    generated = artifacts.get('generated_regressions_sha256', {})
    nested.validate_seeds(generated, manifest['source'])
    actual_generated = {}
    for path in seed_paths:
        target = source / path
        require(proptest_seed_file(target), 'invalid downloaded seed bytes')
        if path in manifest['source']['files']:
            require(file_digest(target) == manifest['source']['files'][path], 'tracked seed input differs')
        else:
            actual_generated[path] = file_digest(target)
    require(actual_generated == generated, 'missing, extra or modified generated seeds')
    if code == 1:
        require(any(path.endswith('.proptest-regressions') for path in generated), 'missing live fallback seed for exit1 guard')
    required_steps = ['Authorize original source and failure eligibility; inspect original evidence only',
                      'Verify independent manifest SHA and original partition',
                      'Run only the original frozen shard and its baseline',
                      'Attest the live source and identify the actual sealer',
                      'Record recovery provenance and verify raw reports against the seal',
                      'Preserve recovery evidence without build outputs']
    execution = None
    for name in required_steps:
        rows = [step for step in job['steps'] if step['name'] == name]
        require(len(rows) == 1 and rows[0]['status'] == 'completed' and rows[0]['conclusion'] == 'success',
                'required recovery step did not complete successfully')
        if name == required_steps[2]:
            execution = rows[0]
    require(timestamp(execution['started_at']) <= timestamp(outcomes['start_time'])
            and nested.within_api_completion(outcomes['end_time'], execution['completed_at'])
            and timestamp(run['created_at']) <= timestamp(outcomes['start_time']), 'raw times are not inside fresh execution')
    old_key = f'target/final-mutation-shard-{INDEX}/mutants.out/outcomes.json'
    require(file_digest(raw / 'outcomes.json') != authorization['collection_inspection']['members_sha256'][old_key],
            'fresh outcomes cannot reuse unattested original raw bytes')
    log = (DIRECTORY / 'job.log').read_text()
    runtime_inputs = {}
    for key, expected in [('JOB', '126992343007'), ('INDEX', '46'), ('RECOVERY_RUN', str(RUN)),
                          ('CONTROLLER', CONTROLLER), ('FROZEN_SOURCE', recovery.SOURCE)]:
        values = set(re.findall(r'Z\s+' + key + r':\s*([^\r\n]+)\r?$', log, re.M))
        require(values == {expected}, f'actual API job log input {key} differs or is missing')
        runtime_inputs[key] = expected
    toolchain = (evidence / 'toolchain.txt').read_text()
    require('snapshot=' + recovery.SOURCE in toolchain and 'rustc 1.98.1' in toolchain
            and 'cargo-mutants 27.1.0' in toolchain, 'toolchain/source provenance differs')
    for outcome in outcomes['outcomes']:
        log_path = Path(outcome['log_path'])
        require(not log_path.is_absolute() and '..' not in log_path.parts and (raw / log_path).is_file(), 'missing outcome log')
    report = {'format_version': 1, 'verified_at': datetime.now(timezone.utc).isoformat(),
              'status': 'authenticated_complete_fresh_shard', 'run_id': RUN, 'job_id': JOB,
              'artifact_id': artifact['id'], 'artifact_zip_sha256': hashlib.sha256(blob).hexdigest(),
              'controller_revision': CONTROLLER, 'source_revision': recovery.SOURCE, 'shard': SHARD,
              'runtime_inputs_verified_from_api_job_log': runtime_inputs,
              'authorization_format_version': 2, 'authorization_sha256': file_digest(control / 'authorization.json'),
              'recovery_metadata_sha256': file_digest(control / 'recovery-metadata.json'),
              'baseline': baseline, 'candidate_count': len(candidates),
              'raw_counts': {key: outcomes[key] for key in ('caught', 'missed', 'unviable', 'timeout')},
              'raw_start_time': outcomes['start_time'], 'raw_end_time': outcomes['end_time'],
              'raw_outcomes_sha256': file_digest(raw / 'outcomes.json'), 'candidates_sha256': file_digest(raw / 'mutants.json'),
              'runner_exit_code': code, 'cargo_mutants_exit_code': metadata['cargo_mutants_exit_code'],
              'sealer': sealer, 'seal_relative_path': relative_seal, 'generated_seeds_sha256': generated,
              'original46_raw_reused': False, 'new_global_union_applied': False,
              'quality_gate': 'not evaluated; all81 outcomes retained including missed/timeout',
              'verification_scope': 'API/ZIP/v2 authorization/fresh baseline/raw+seal/seed bytes/controller-live-source provenance; no Cargo or source reconstruction',
              'input_files_sha256': {name: file_digest(DIRECTORY / name) for name in
                                     ('run.json', 'jobs.json', 'artifacts.json', 'artifact-api.json', 'job.log')},
              'verification_script_sha256': file_digest(Path(__file__))}
    (DIRECTORY / 'verified-recovery46.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: report[key] for key in ('status', 'candidate_count', 'raw_counts', 'runner_exit_code',
                                                 'cargo_mutants_exit_code', 'raw_start_time', 'raw_end_time')}, separators=(',', ':')))
    print('report_sha256', file_digest(DIRECTORY / 'verified-recovery46.json'))


if __name__ == '__main__':
    main()
