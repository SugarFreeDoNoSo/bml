from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import subprocess
import tomllib

root = Path('/home/dev/Work/bml')
parser = argparse.ArgumentParser()
parser.add_argument('--plan', type=Path, required=True)
parser.add_argument('--worktree', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--build-target', type=Path, default=root / 'target/mutation-replay-build')
args = parser.parse_args()
worktree = args.worktree.resolve()
cases = json.loads(args.plan.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
manifest = json.loads((root / 'target/quality/mutation-plan-41950170549/campaign.json').read_text())
candidates = {candidate['name']: candidate for candidate in manifest['candidates']}
env = os.environ.copy()
build_target = args.build_target.resolve()
assert build_target != (root / 'target/entrypoint-repair-build').resolve(), 'replays require their own build target'
env['CARGO_TARGET_DIR'] = str(build_target)
packages = set()
for case in cases:
    candidate = candidates[case['candidate']]
    source = worktree / candidate['file']
    assert sha(source) == manifest['source']['files'][candidate['file']], candidate['name']
    for parent in source.parents:
        assert parent.is_relative_to(worktree), candidate['file']
        package_manifest = parent / 'Cargo.toml'
        if package_manifest.is_file():
            data = tomllib.loads(package_manifest.read_text())
            if 'package' in data:
                packages.add(data['package']['name'])
                break
    else:
        raise AssertionError('no Cargo package for ' + candidate['file'])
report = {
    'scope': 'Isolated semantic mutation replays with additional public-contract tests; not a complete mutation campaign or a passing global score.',
    'campaign_run': 41950170549,
    'candidate_source_revision': manifest['source']['revision'],
    'worktree_base_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, text=True).strip(),
    'baselines': [], 'replays': [],
    'build_target': str(build_target), 'cleaned_packages': sorted(packages), 'cleanup': [],
}

def run(label, command):
    log = root / f'target/quality/survivor-replay-{label}.log'
    try:
        with log.open('w') as out:
            result = subprocess.run(command, cwd=worktree, env=env, stdout=out,
                                    stderr=subprocess.STDOUT, timeout=360)
        code = result.returncode
    except subprocess.TimeoutExpired:
        code = 'timeout'
    text = log.read_text()
    return {'command': command, 'exit_code': code, 'log': str(log.relative_to(root)),
            'log_sha256': sha(log), 'test_failed': 'test result: FAILED.' in text,
            'compile_error': 'could not compile' in text,
            'selected_tests': [list(row) for row in re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$', text, re.MULTILINE)]}

def persist():
    report['observed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(report, indent=2) + '\n')

def clean(label):
    command = ['cargo', 'clean', '--locked']
    for package in sorted(packages):
        command.extend(['-p', package])
    result = run('clean-' + args.output.stem + '-' + label, command)
    report['cleanup'].append(result)
    persist()
    assert result['exit_code'] == 0, result

# Cargo fingerprints can reuse a mutated library across worktrees when the
# restored source in another checkout has an older mtime. Keep the replay
# target separate and remove only our workspace package outputs, preserving
# downloaded dependencies and their compiled artifacts.
clean('before-baselines')

unique = {}
for case in cases:
    unique.setdefault(tuple(case['command']), case['label'])
for command, label in unique.items():
    result = run('baseline-' + label, list(command))
    report['baselines'].append(result)
    persist()
    assert (result['exit_code'] == 0 and not result['compile_error']
            and len(result['selected_tests']) == 1
            and result['selected_tests'][0][1] == 'ok'), result
print('BASELINES', len(unique), 'passed', flush=True)

for case in cases:
    candidate = candidates[case['candidate']]
    source = worktree / candidate['file']
    original = source.read_bytes()
    assert sha(source) == manifest['source']['files'][candidate['file']], candidate['name']
    lines = original.splitlines(keepends=True)
    span = candidate['span']
    offsets = [sum(map(len, lines[:span[side]['line'] - 1])) + span[side]['column'] - 1
               for side in ['start', 'end']]
    start, end = offsets
    assert 0 <= start < end <= len(original), span
    replacement = candidate['replacement'].encode()
    changed = original[:start] + replacement + original[end:]
    try:
        source.write_bytes(changed)
        result = run(case['label'], case['command'])
    finally:
        source.write_bytes(original)
        clean('restored-' + case['label'])
    result.update(label=case['label'], candidate=candidate['name'],
                  original_source_sha256=hashlib.sha256(original).hexdigest(),
                  mutated_source_sha256=hashlib.sha256(changed).hexdigest(),
                  original_diff_sha256=hashlib.sha256(candidate['diff'].encode()).hexdigest(),
                  original_span=span,
                  detected=(result['exit_code'] == 101 and result['test_failed']
                            and not result['compile_error']
                            and len(result['selected_tests']) == 1
                            and result['selected_tests'][0][1] == 'FAILED'))
    report['replays'].append(result)
    persist()
    print(case['label'], result['detected'], result['exit_code'], flush=True)
report['status'] = 'passed_focused_replays' if all(row['detected'] for row in report['replays']) else 'needs_investigation'
persist()
assert len(report['replays']) == len(cases) and all(row['detected'] for row in report['replays'])
