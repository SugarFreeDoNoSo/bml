# TinyLlama two-position diagnostic evidence

This bundle preserves the complete native and symbolic logit vectors for the
fixed token IDs `[1, 29958]`. Each vector contains 32,000 little-endian IEEE f64
values (256,000 bytes). The independent native and symbolic KV caches reached
positions 1 and 2. Both argmax sequences are `[29958, 13]`.

Run the portable check after extracting this bundle, from its directory:

```sh
python3 verify_tinyllama.py --results-only
```

This mode needs only Python 3's standard library and these saved files. It
checks sizes, finiteness, hashes, argmax, maximum/mean/RMS absolute errors,
position JSON, final summary, log and exit status. It also checks the saved
complete verification receipt and historical override hashes. It does not
require or inspect a repository, model, AOT programs, measured binary, or the
old PID. To retain its output, write outside this extracted directory.

The complete check additionally requires the original files at their recorded
paths inside a BML checkout, and historical Git object `236a46d3cff6cb1f1951894a231743fc90154c8c`:

```sh
python3 verify_tinyllama.py /absolute/path/to/bml
```

It hashes the GGUF (`da3087fb...`), AOT manifest (`0b6e9bc3...`), all twelve AOT
programs, measured binary (`6457b36d...`) and retained build-output JSONL. The
large model, AOT programs, binary and build-output JSONL are deliberately absent
from this results bundle. Their exact hashes and sizes are recorded in the
complete verification receipt. The original PID's absence is checked only in
complete mode; PID reuse on a later host is not evidence about the old run.

The measured binary used historical base `236a46d3...` plus recorded overrides:
`Cargo.lock`, `crates/runtime/Cargo.toml`, and the added diagnostic test. All
three overrides are included, hash checked against the captured campaign.
The other 289 captured source hashes match that Git base. This does not validate
current main. The build supplement is retrospective and does not authenticate
the original compiler invocation or environment. The captured campaign record
still says `completed_unverified`; the separate verification receipts document
the subsequent independent checks without rewriting that historical record.

The persisted bounded AOT profile has context 2; the captured test loads it with
`max_nodes=0`. Its source, profile, inputs and program hashes are recorded in the
campaign and checked in complete mode. No execution is repeated by this verifier.

These are diagnostic observations with no preset numerical tolerance. Matching
argmax values do not establish global numerical parity, throughput, performance,
distributed-host completion, or completion of OpenSpec task 8.6. The logged
durations are retained observations, not a performance qualification.

Archive packaging uses sorted members, normalized mtime/uid/gid 0, empty
owner/group names, fixed file modes and gzip mtime 0. Its adjacent metadata lists
the exact member hashes and archive digest. The archive contains only this
directory's TinyLlama evidence.
