#!/usr/bin/env python3
"""Recheck saved two-position diagnostic bytes; this sets no parity threshold.

Portable: python3 verify_tinyllama.py --results-only
Full: python3 verify_tinyllama.py /absolute/path/to/bml
The JSON/log/vector inputs are immutable copies adjacent to this script. Large
GGUF/AOT/binary inputs remain at their recorded repository paths and are hashed.
"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import struct
import subprocess
import sys


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def blob_sha(data):
    return hashlib.sha256(data).hexdigest()


def argmax(values):
    # Rust Iterator::max_by chooses the last equal maximum. All inputs are
    # finite; explicitly include the index to preserve that tie convention.
    return max(range(len(values)), key=lambda index: (values[index], index))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repository", type=Path, nargs="?")
    parser.add_argument("--results-only", action="store_true", help="Verify saved results without repository, GGUF, AOT or measured binary")
    args = parser.parse_args()
    if args.repository is None and not args.results_only:
        parser.error("repository is required unless --results-only is selected")
    repository = args.repository.resolve() if args.repository else None
    snapshot = Path(__file__).resolve().parent
    campaign = json.loads((snapshot / "tinyllama-two-position-diagnostic.json").read_text())
    build = json.loads((snapshot / "tinyllama-two-position-build.json").read_text())
    vector_dir = snapshot / "tinyllama-two-position-logits"
    summary = json.loads((vector_dir / "summary.json").read_text())
    log = (snapshot / "tinyllama-two-position-diagnostic.log").read_text()
    exit_code = int((snapshot / "tinyllama-two-position-diagnostic.exit").read_text())
    assert exit_code == campaign["exit_code"] == 0
    if not args.results_only:
        assert not (Path("/proc") / str(campaign["pid"])).exists()
    assert "test real_model_two_position_symbolic_logit_diagnostic ... ok" in log
    assert "test result: ok. 1 passed; 0 failed;" in log
    log_positions = [json.loads(line) for line in log.splitlines() if line.startswith("{")]
    assert len(log_positions) == 2
    assert summary["input_ids"] == campaign["input_ids"] == [1, 29958]
    assert summary["qualification"] == "diagnostic only; no preset tolerance or numerical parity claim"
    assert len(summary["positions"]) == 2
    reports = []
    vector_receipts = []
    for position in range(2):
        saved = json.loads((vector_dir / f"position-{position}.json").read_text())
        assert saved == summary["positions"][position] == log_positions[position]
        assert saved["position"] == position
        assert saved["input_token"] == summary["input_ids"][position]
        assert saved["native_cache_position"] == saved["symbolic_cache_position"] == position + 1
        assert saved["logits"] == 32000
        assert saved["symbolic_elapsed_seconds"] > 0
        vectors = []
        for kind in ("native", "symbolic"):
            name = saved[f"{kind}_vector"]
            assert name == f"{kind}-{position}.f64le"
            path = vector_dir / name
            data = path.read_bytes()
            assert len(data) == 32000 * 8
            values = struct.unpack("<32000d", data)
            assert all(math.isfinite(value) for value in values)
            index = argmax(values)
            assert saved[f"{kind}_argmax"] == index
            vectors.append(values)
            vector_receipts.append({
                "file": name, "bytes": len(data), "f64le_values": len(values),
                "all_finite": True, "sha256": blob_sha(data), "argmax": index,
                "argmax_multiplicity": sum(value == values[index] for value in values),
            })
        differences = [abs(a - b) for a, b in zip(*vectors)]
        maximum = max(differences)
        mean = 0.0
        squares = 0.0
        # Reproduce the recorded explicit f64 reduction order, independently
        # reading raw vectors. Equality here checks report integrity only.
        for difference in differences:
            mean += difference / len(differences)
            if maximum:
                scaled = difference / maximum
                squares += scaled * scaled
        rms = maximum * math.sqrt(squares / len(differences)) if maximum else 0.0
        recomputed = {"max_absolute_error": maximum, "mean_absolute_error": mean, "rms_error": rms}
        assert all(saved[key] == value for key, value in recomputed.items())
        # Also retain a compensated summation cross-check; no error budget or
        # numerical-parity acceptance criterion is inferred from either mean.
        reports.append({
            **saved, "recomputed": recomputed, "saved_statistics_match_exactly": True,
            "mean_absolute_error_fsum": math.fsum(differences) / len(differences),
        })
    assert summary["input_ids"][1] == reports[0]["native_argmax"] == reports[0]["symbolic_argmax"]
    assert [report["native_argmax"] for report in reports] == [29958, 13]
    assert [report["symbolic_argmax"] for report in reports] == [29958, 13]

    if not args.results_only:
        receipts = []
        expected_files = {
            campaign["source"]: campaign["source_sha256"],
            campaign["binary"]: campaign["binary_sha256"],
            campaign["manifest"]: campaign["manifest_sha256"],
            **campaign["artifact_hashes"],
            build["compiler_artifact_build_record"]["path"]:
                build["compiler_artifact_build_record"]["sha256"],
        }
        assert campaign["source_sha256"] == "da3087fb14aede55fde6eb81a0e55e886810e43509ec82ecdc7aa5d62a03b556"
        assert campaign["manifest_sha256"] == "0b6e9bc33693e9581676fad805fec2cf2173410c1ba112ddce99f490709bbd97"
        assert campaign["binary_sha256"] == build["measured_binary_sha256"]
        for relative, expected in expected_files.items():
            path = repository / relative
            actual = sha(path)
            assert actual == expected, (relative, actual, expected)
            receipts.append({"path": relative, "bytes": path.stat().st_size, "sha256": actual})
        manifest = json.loads((repository / campaign["manifest"]).read_text())
        assert manifest["version"] == 4 and manifest["context_length"] == 2
        assert manifest["source_sha256"] == campaign["source_sha256"]
        assert manifest["bounded_profile"] == campaign["profile"]

        base = campaign["base_revision"]
        assert base == "236a46d3cff6cb1f1951894a231743fc90154c8c"
        matches = []
        overrides = []
        for name, expected in campaign["source_hashes_at_build"].items():
            original = subprocess.run(["git", "show", f"{base}:{name}"], cwd=repository, capture_output=True)
            if original.returncode == 0 and blob_sha(original.stdout) == expected:
                matches.append(name)
            else:
                replacement = snapshot / "historical-overrides" / name
                assert sha(replacement) == expected, name
                overrides.append({
                    "path": name, "sha256": expected, "snapshot_path": str(replacement.relative_to(snapshot)),
                    "base_state": "absent" if original.returncode else "different",
                })
        assert len(matches) == 289
        assert {item["path"] for item in overrides} == {
            "Cargo.lock", "crates/runtime/Cargo.toml", "crates/runtime/tests/real_model_two_position_diagnostic.rs",
        }
        root_manifest = subprocess.check_output(["git", "show", f"{base}:Cargo.toml"], cwd=repository)
        assert blob_sha(root_manifest) == build["root_manifest"]["sha256"]
        assert build["root_manifest"]["matches_base_revision"] == base
    else:
        receipts = []
        base = campaign["base_revision"]
        matches = []
        overrides = []
        for name in ["Cargo.lock", "crates/runtime/Cargo.toml", "crates/runtime/tests/real_model_two_position_diagnostic.rs"]:
            replacement = snapshot / "historical-overrides" / name
            assert sha(replacement) == campaign["source_hashes_at_build"][name]
            overrides.append({"path": name, "sha256": sha(replacement), "snapshot_path": str(replacement.relative_to(snapshot)), "base_state": "not_rechecked_without_repository"})
    source_test = (snapshot / "historical-overrides/crates/runtime/tests/real_model_two_position_diagnostic.rs").read_text()
    assert "max_nodes: 0" in source_test
    assert "let ids = [1u32, 29958]" in source_test
    operations = json.loads(summary["operations"])
    assert operations == ["attention_dot", "dot", "down_dot", "residual_add", "rms_norm", "rope", "scale", "softmax", "swiglu", "weighted_sum"]
    completed = re.search(r"finished in ([0-9.]+)s", log)
    assert completed
    result = {
        "status": "verified_saved_results" if args.results_only else "verified_completed_diagnostic",
        "mode": "results-only" if args.results_only else "complete", "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Two fixed historical-binary TinyLlama positions; byte and report integrity only. No preset numerical tolerance, parity, throughput or performance claim.",
        "pid": campaign["pid"], "process_absent": None if args.results_only else True, "exit_code": exit_code,
        "captured_campaign_status": campaign["status"], "captured_campaign_ended_at_utc": campaign.get("ended_at_utc"),
        "input_ids": summary["input_ids"], "positions": reports, "vectors": vector_receipts,
        "artifact_inputs": receipts, "executed_operations": operations,
        "test_harness_elapsed_seconds": float(completed.group(1)),
        "historical_source_provenance": {
            "base_revision": base, "recorded_source_count": len(campaign["source_hashes_at_build"]),
            "repository_checks_performed": not args.results_only,
            "base_matching_count": None if args.results_only else len(matches), "verified_overrides": overrides,
            "root_manifest_matches_build_record_and_base": None if args.results_only else True,
            "build_record_scope": build["scope"],
            "qualification": ("Repository/GGUF/AOT/binary and historical Git checks are not repeated in results-only mode. Saved vector/report integrity and override hashes are checked." if args.results_only else "Base plus recorded hash-verified overrides reconstructs captured source inputs. Retrospective build record does not authenticate the original compiler invocation/environment; this execution is not current-main validation."),
        },
        "saved_inputs": [
            {"path": str(path.relative_to(snapshot)), "bytes": path.stat().st_size, "sha256": sha(path)}
            for path in sorted(snapshot.rglob("*")) if path.is_file() and path.name not in {"tinyllama-verification.json", "tinyllama-results-only-verification.json", "tinyllama-verification.stderr"}
        ],
        "verifier": {"path": "verify_tinyllama.py", "sha256": sha(Path(__file__)),
            "command": ([sys.executable, "verify_tinyllama.py", "--results-only"] if args.results_only else [sys.executable, str(Path(__file__).resolve()), str(repository)])},
    }
    if args.results_only:
        saved_complete = json.loads((snapshot / "tinyllama-verification.json").read_text())
        assert saved_complete["status"] == "verified_completed_diagnostic"
        assert saved_complete["vectors"] == vector_receipts
        assert saved_complete["positions"] == reports
        assert saved_complete["input_ids"] == summary["input_ids"]
        assert saved_complete["exit_code"] == exit_code
        assert saved_complete["executed_operations"] == operations
        assert saved_complete["verifier"]["sha256"] == sha(Path(__file__))
        for receipt in saved_complete["saved_inputs"]:
            source = snapshot / receipt["path"]
            assert source.is_file() and source.stat().st_size == receipt["bytes"]
            assert sha(source) == receipt["sha256"], receipt["path"]
        result["saved_complete_verification_agrees"] = True
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
